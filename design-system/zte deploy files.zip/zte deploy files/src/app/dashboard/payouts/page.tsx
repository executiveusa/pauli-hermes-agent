"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Plus, CheckCircle, Clock, Trash2, Eye } from "lucide-react"
import { Button } from "@/components/ui"

interface Payout {
  id: string
  amount: number
  status: string
  hoursWorked: number
  periodStart: string
  periodEnd: string
  caregiver: { firstName: string; lastName: string }
  paidAt: string | null
  createdAt: string
}

const statusColors: { [key: string]: string } = {
  PENDING: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  APPROVED: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  PROCESSING: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  PAID: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  FAILED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
}

export default function PayoutsPage() {
  const { data: session } = useSession()
  const [payouts, setPayouts] = useState<Payout[]>([])
  const [loading, setLoading] = useState(true)
  const [showNewForm, setShowNewForm] = useState(false)
  const [filter, setFilter] = useState<string>("")
  const [page, setPage] = useState(1)

  useEffect(() => {
    const fetchPayouts = async () => {
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: "20",
        })
        if (filter) {
          params.append("status", filter)
        }
        const response = await fetch(`/api/payouts?${params}`)
        if (response.ok) {
          const data = await response.json()
          setPayouts(data.data)
        }
      } catch (error) {
        console.error("Error fetching payouts:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchPayouts()
    }
  }, [session, page, filter])

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this payout?")) {
      try {
        const response = await fetch(`/api/payouts/${id}`, {
          method: "DELETE",
        })
        if (response.ok) {
          setPayouts(payouts.filter((payout) => payout.id !== id))
        }
      } catch (error) {
        console.error("Error deleting payout:", error)
      }
    }
  }

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/payouts/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      })
      if (response.ok) {
        const updated = await response.json()
        setPayouts(payouts.map((p) => (p.id === id ? updated : p)))
      }
    } catch (error) {
      console.error("Error updating payout:", error)
    }
  }

  if (loading) {
    return <div>Loading payouts...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Caregiver Payouts
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage and process caregiver payments
          </p>
        </div>
        <Button
          variant="premium"
          onClick={() => setShowNewForm(!showNewForm)}
          className="gap-2"
        >
          <Plus className="h-5 w-5" />
          New Payout
        </Button>
      </div>

      {showNewForm && (
        <div className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            Create New Payout
          </h2>
          <form className="mt-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Caregiver
              </label>
              <select className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                <option>Select a caregiver...</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Amount
                </label>
                <input
                  type="number"
                  placeholder="0.00"
                  className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Hours Worked
                </label>
                <input
                  type="number"
                  placeholder="0.00"
                  className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Period Start
                </label>
                <input
                  type="date"
                  className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Period End
                </label>
                <input
                  type="date"
                  className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="rounded-lg bg-amber-500 px-4 py-2 text-white hover:bg-amber-600"
              >
                Create Payout
              </button>
              <button
                type="button"
                onClick={() => setShowNewForm(false)}
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="rounded-lg bg-white shadow dark:bg-gray-800">
        <div className="border-b border-gray-200 p-4 dark:border-gray-700">
          <div className="flex gap-2">
            {["", "PENDING", "APPROVED", "PROCESSING", "PAID", "FAILED"].map((status) => (
              <button
                key={status}
                onClick={() => {
                  setFilter(status)
                  setPage(1)
                }}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                  filter === status
                    ? "bg-amber-500 text-white"
                    : "bg-gray-100 text-gray-900 hover:bg-gray-200 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
                }`}
              >
                {status || "All"}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Caregiver
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Hours
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Period
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-900 dark:text-white">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {payouts.map((payout) => (
                <tr key={payout.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
                    {payout.caregiver.firstName} {payout.caregiver.lastName}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    ${(payout.amount / 100).toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    {payout.hoursWorked.toFixed(2)} hrs
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-400">
                    {new Date(payout.periodStart).toLocaleDateString()} to{" "}
                    {new Date(payout.periodEnd).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                        statusColors[payout.status]
                      }`}
                    >
                      {payout.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      {payout.status === "PENDING" && (
                        <button
                          onClick={() => handleUpdateStatus(payout.id, "APPROVED")}
                          className="text-green-600 hover:text-green-800 dark:text-green-400"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </button>
                      )}
                      {payout.status === "APPROVED" && (
                        <button
                          onClick={() => handleUpdateStatus(payout.id, "PAID")}
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                        >
                          <Clock className="h-4 w-4" />
                        </button>
                      )}
                      <button
                        onClick={() => handleDelete(payout.id)}
                        className="text-red-600 hover:text-red-800 dark:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
