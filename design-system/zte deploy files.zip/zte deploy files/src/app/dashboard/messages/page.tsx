"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Send, Trash2, Mail, MailOpen } from "lucide-react"
import { Button } from "@/components/ui"

interface Message {
  id: string
  content: string
  read: boolean
  readAt: string | null
  sender: { name: string; email: string }
  receiver: { name: string; email: string }
  createdAt: string
}

export default function MessagesPage() {
  const { data: session } = useSession()
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [folder, setFolder] = useState<"inbox" | "sent" | "unread">("inbox")
  const [showCompose, setShowCompose] = useState(false)
  const [page, setPage] = useState(1)

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: "20",
          folder,
        })
        const response = await fetch(`/api/messages?${params}`)
        if (response.ok) {
          const data = await response.json()
          setMessages(data.data)
        }
      } catch (error) {
        console.error("Error fetching messages:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchMessages()
    }
  }, [session, page, folder])

  const handleDelete = async (id: string) => {
    if (confirm("Delete this message?")) {
      try {
        const response = await fetch(`/api/messages/${id}`, {
          method: "DELETE",
        })
        if (response.ok) {
          setMessages(messages.filter((msg) => msg.id !== id))
        }
      } catch (error) {
        console.error("Error deleting message:", error)
      }
    }
  }

  const handleMarkAsRead = async (id: string) => {
    try {
      const response = await fetch(`/api/messages/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ read: true }),
      })
      if (response.ok) {
        setMessages(
          messages.map((msg) =>
            msg.id === id ? { ...msg, read: true, readAt: new Date().toISOString() } : msg
          )
        )
      }
    } catch (error) {
      console.error("Error marking as read:", error)
    }
  }

  if (loading) {
    return <div>Loading messages...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Messages
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Internal team communication
          </p>
        </div>
        <Button
          variant="premium"
          onClick={() => setShowCompose(!showCompose)}
          className="gap-2"
        >
          <Send className="h-5 w-5" />
          New Message
        </Button>
      </div>

      {showCompose && (
        <div className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            Compose Message
          </h2>
          <form className="mt-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Recipient
              </label>
              <input
                type="email"
                placeholder="recipient@email.com"
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Message
              </label>
              <textarea
                placeholder="Type your message..."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                rows={4}
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="rounded-lg bg-amber-500 px-4 py-2 text-white hover:bg-amber-600"
              >
                Send
              </button>
              <button
                type="button"
                onClick={() => setShowCompose(false)}
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="rounded-lg bg-white shadow dark:bg-gray-800">
        <div className="border-b border-gray-200 p-4 dark:border-gray-700">
          <div className="flex gap-2">
            {(["inbox", "sent", "unread"] as const).map((f) => (
              <button
                key={f}
                onClick={() => {
                  setFolder(f)
                  setPage(1)
                }}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                  folder === f
                    ? "bg-amber-500 text-white"
                    : "bg-gray-100 text-gray-900 hover:bg-gray-200 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
                }`}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700 ${
                !message.read ? "bg-blue-50 dark:bg-blue-900/20" : ""
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {!message.read && <Mail className="h-4 w-4 text-blue-600" />}
                    {message.read && <MailOpen className="h-4 w-4 text-gray-400" />}
                    <p className="font-semibold text-gray-900 dark:text-white">
                      {folder === "sent" ? message.receiver.name : message.sender.name}
                    </p>
                  </div>
                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    {message.content}
                  </p>
                  <p className="mt-2 text-xs text-gray-500 dark:text-gray-500">
                    {new Date(message.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="flex gap-2 ml-4">
                  {!message.read && folder === "inbox" && (
                    <button
                      onClick={() => handleMarkAsRead(message.id)}
                      className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                    >
                      Mark as read
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(message.id)}
                    className="text-red-600 hover:text-red-800 dark:text-red-400"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
