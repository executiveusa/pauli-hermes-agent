"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Plus, Trash2, Eye } from "lucide-react"
import { Button } from "@/components/ui"
import { format } from "date-fns"

interface Shift {
  id: string
  client: { firstName: string; lastName: string }
  caregiver: { firstName: string; lastName: string }
  scheduledStart: string
  scheduledEnd: string
  status: string
  totalHours?: number
  totalAmount?: number
}

export default function ShiftsPage() {
  const { data: session } = useSession()
  const [shifts, setShifts] = useState<Shift[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchShifts = async () => {
      try {
        const response = await fetch("/api/shifts")
        if (response.ok) {
          const data = await response.json()
          setShifts(data)
        }
      } catch (error) {
        console.error("Error fetching shifts:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchShifts()
    }
  }, [session])

  if (loading) {
    return <div>Loading shifts...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Shifts
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage care schedules
          </p>
        </div>
        <Button variant="premium" className="gap-2">
          <Plus className="h-5 w-5" />
          Schedule Shift
        </Button>
      </div>

      {/* Shifts Table */}
      <div className="overflow-x-auto rounded-lg bg-white shadow dark:bg-gray-800">
        <table className="w-full">
          <thead className="border-b border-gray-200 dark:border-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Client
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Caregiver
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Start
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                End
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Status
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Amount
              </th>
            </tr>
          </thead>
          <tbody>
            {shifts.map((shift) => (
              <tr
                key={shift.id}
                className="border-b border-gray-200 dark:border-gray-700"
              >
                <td className="px-6 py-4 text-gray-900 dark:text-white">
                  {shift.client.firstName} {shift.client.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {shift.caregiver.firstName} {shift.caregiver.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {format(new Date(shift.scheduledStart), "MMM dd, yyyy HH:mm")}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {format(new Date(shift.scheduledEnd), "MMM dd, yyyy HH:mm")}
                </td>
                <td className="px-6 py-4">
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${
                      shift.status === "COMPLETED"
                        ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
                    }`}
                  >
                    {shift.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-gray-900 dark:text-white">
                  ${((shift.totalAmount || 0) / 100).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {shifts.length === 0 && (
        <div className="rounded-lg bg-white p-12 text-center shadow dark:bg-gray-800">
          <p className="text-gray-600 dark:text-gray-400">
            No shifts scheduled yet. Schedule your first shift to get started.
          </p>
        </div>
      )}
    </div>
  )
}
