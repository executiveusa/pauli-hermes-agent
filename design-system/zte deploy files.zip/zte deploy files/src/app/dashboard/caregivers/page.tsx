"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Plus, Trash2, Eye } from "lucide-react"
import { Button } from "@/components/ui"
import Link from "next/link"

interface Caregiver {
  id: string
  firstName: string
  lastName: string
  email: string
  phone: string
  status: string
  yearsExperience: number
  rating: number
}

export default function CaregiversPage() {
  const { data: session } = useSession()
  const [caregivers, setCaregivers] = useState<Caregiver[]>([])
  const [loading, setLoading] = useState(true)
  const [showNewForm, setShowNewForm] = useState(false)

  useEffect(() => {
    const fetchCaregivers = async () => {
      try {
        const response = await fetch("/api/caregivers")
        if (response.ok) {
          const data = await response.json()
          setCaregivers(data)
        }
      } catch (error) {
        console.error("Error fetching caregivers:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchCaregivers()
    }
  }, [session])

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this caregiver?")) {
      try {
        const response = await fetch(`/api/caregivers/${id}`, {
          method: "DELETE",
        })
        if (response.ok) {
          setCaregivers(caregivers.filter((c) => c.id !== id))
        }
      } catch (error) {
        console.error("Error deleting caregiver:", error)
      }
    }
  }

  if (loading) {
    return <div>Loading caregivers...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Caregivers
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage your care team
          </p>
        </div>
        <Button
          variant="premium"
          onClick={() => setShowNewForm(!showNewForm)}
          className="gap-2"
        >
          <Plus className="h-5 w-5" />
          Add Caregiver
        </Button>
      </div>

      {showNewForm && (
        <div className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            New Caregiver
          </h2>
          <form className="mt-4 space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <input
                type="text"
                placeholder="First Name"
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
              <input
                type="text"
                placeholder="Last Name"
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
              <input
                type="email"
                placeholder="Email"
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
              <input
                type="tel"
                placeholder="Phone"
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
              <input
                type="number"
                placeholder="Years of Experience"
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
              <input
                type="number"
                placeholder="Hourly Rate (in cents)"
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
            </div>
            <div className="flex gap-4">
              <Button variant="premium" type="submit">
                Save Caregiver
              </Button>
              <Button
                variant="outline"
                type="button"
                onClick={() => setShowNewForm(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Caregivers Table */}
      <div className="overflow-x-auto rounded-lg bg-white shadow dark:bg-gray-800">
        <table className="w-full">
          <thead className="border-b border-gray-200 dark:border-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Name
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Email
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Phone
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Experience
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Rating
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Status
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {caregivers.map((caregiver) => (
              <tr
                key={caregiver.id}
                className="border-b border-gray-200 dark:border-gray-700"
              >
                <td className="px-6 py-4 text-gray-900 dark:text-white">
                  {caregiver.firstName} {caregiver.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {caregiver.email}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {caregiver.phone}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {caregiver.yearsExperience} years
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <span
                        key={i}
                        className={
                          i < Math.floor(caregiver.rating)
                            ? "text-gold-400"
                            : "text-gray-300"
                        }
                      >
                        ★
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${
                      caregiver.status === "ACTIVE"
                        ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-400"
                    }`}
                  >
                    {caregiver.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <Link href={`/dashboard/caregivers/${caregiver.id}`}>
                      <Eye className="h-5 w-5 text-blue-600 hover:text-blue-800 dark:text-blue-400" />
                    </Link>
                    <button
                      onClick={() => handleDelete(caregiver.id)}
                      className="text-red-600 hover:text-red-800 dark:text-red-400"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {caregivers.length === 0 && (
        <div className="rounded-lg bg-white p-12 text-center shadow dark:bg-gray-800">
          <p className="text-gray-600 dark:text-gray-400">
            No caregivers yet. Add your first caregiver to get started.
          </p>
        </div>
      )}
    </div>
  )
}
