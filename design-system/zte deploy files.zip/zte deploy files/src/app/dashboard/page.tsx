"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Users, ClipboardList, FileText, DollarSign } from "lucide-react"

interface DashboardStats {
  clientsCount: number
  caregiversCount: number
  shiftsCount: number
  totalRevenue: number
}

export default function DashboardPage() {
  const { data: session } = useSession()
  const [stats, setStats] = useState<DashboardStats>({
    clientsCount: 0,
    caregiversCount: 0,
    shiftsCount: 0,
    totalRevenue: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [clientsRes, caregiversRes, shiftsRes, invoicesRes] = await Promise.all([
          fetch("/api/clients"),
          fetch("/api/caregivers"),
          fetch("/api/shifts"),
          fetch("/api/invoices"),
        ])

        const clients = await clientsRes.json()
        const caregivers = await caregiversRes.json()
        const shifts = await shiftsRes.json()
        const invoices = await invoicesRes.json()

        const totalRevenue = invoices.reduce(
          (sum: number, inv: any) => sum + (inv.total || 0),
          0
        )

        setStats({
          clientsCount: clients.length,
          caregiversCount: caregivers.length,
          shiftsCount: shifts.length,
          totalRevenue,
        })
      } catch (error) {
        console.error("Error fetching stats:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchStats()
    }
  }, [session])

  const statCards = [
    {
      icon: Users,
      label: "Total Clients",
      value: stats.clientsCount,
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: Users,
      label: "Total Caregivers",
      value: stats.caregiversCount,
      color: "from-green-500 to-green-600",
    },
    {
      icon: ClipboardList,
      label: "Active Shifts",
      value: stats.shiftsCount,
      color: "from-purple-500 to-purple-600",
    },
    {
      icon: DollarSign,
      label: "Total Revenue",
      value: `$${(stats.totalRevenue / 100).toFixed(2)}`,
      color: "from-gold-500 to-gold-600",
    },
  ]

  if (loading) {
    return <div>Loading dashboard...</div>
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          Welcome back, {session?.user?.name}!
        </h1>
        <p className="mt-2 text-gray-600 dark:text-gray-400">
          Here's what's happening with your care business today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => (
          <div
            key={card.label}
            className="rounded-lg bg-white p-6 shadow dark:bg-gray-800"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {card.label}
                </p>
                <p className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                  {card.value}
                </p>
              </div>
              <div className={`rounded-lg bg-gradient-to-br ${card.color} p-3`}>
                <card.icon className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          Quick Actions
        </h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <button className="rounded-lg border-2 border-dashed border-gray-300 p-4 text-center hover:border-gold-500 dark:border-gray-600">
            <p className="text-gray-600 dark:text-gray-400">
              + Add New Client
            </p>
          </button>
          <button className="rounded-lg border-2 border-dashed border-gray-300 p-4 text-center hover:border-gold-500 dark:border-gray-600">
            <p className="text-gray-600 dark:text-gray-400">
              + Add New Caregiver
            </p>
          </button>
          <button className="rounded-lg border-2 border-dashed border-gray-300 p-4 text-center hover:border-gold-500 dark:border-gray-600">
            <p className="text-gray-600 dark:text-gray-400">
              + Schedule Shift
            </p>
          </button>
          <button className="rounded-lg border-2 border-dashed border-gray-300 p-4 text-center hover:border-gold-500 dark:border-gray-600">
            <p className="text-gray-600 dark:text-gray-400">
              + Create Invoice
            </p>
          </button>
        </div>
      </div>
    </div>
  )
}
