"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Plus, AlertTriangle, Trash2, Eye } from "lucide-react"
import { Button } from "@/components/ui"

interface Incident {
  id: string
  title: string
  description: string
  severity: string
  resolved: boolean
  client: { firstName: string; lastName: string }
  caregiver: { firstName: string; lastName: string }
  createdAt: string
}

const severityColors: { [key: string]: string } = {
  LOW: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  MEDIUM: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  HIGH: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  CRITICAL: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
}

export default function IncidentsPage() {
  const { data: session } = useSession()
  const [incidents, setIncidents] = useState<Incident[]>([])
  const [loading, setLoading] = useState(true)
  const [showNewForm, setShowNewForm] = useState(false)
  const [filter, setFilter] = useState<string>("")
  const [page, setPage] = useState(1)

  useEffect(() => {
    const fetchIncidents = async () => {
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: "20",
        })
        if (filter) {
          params.append("severity", filter)
        }
        const response = await fetch(`/api/incidents?${params}`)
        if (response.ok) {
          const data = await response.json()
          setIncidents(data.data)
        }
      } catch (error) {
        console.error("Error fetching incidents:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchIncidents()
    }
  }, [session, page, filter])

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this incident?")) {
      try {
        const response = await fetch(`/api/incidents/${id}`, {
          method: "DELETE",
        })
        if (response.ok) {
          setIncidents(incidents.filter((inc) => inc.id !== id))
        }
      } catch (error) {
        console.error("Error deleting incident:", error)
      }
    }
  }

  if (loading) {
    return <div>Loading incidents...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Incident Reports
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Track and manage incidents and unusual occurrences
          </p>
        </div>
        <Button
          variant="premium"
          onClick={() => setShowNewForm(!showNewForm)}
          className="gap-2"
        >
          <Plus className="h-5 w-5" />
          Report Incident
        </Button>
      </div>

      {showNewForm && (
        <div className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            New Incident Report
          </h2>
          <form className="mt-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Title
              </label>
              <input
                type="text"
                placeholder="Incident title..."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Description
              </label>
              <textarea
                placeholder="Describe what happened..."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                rows={4}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Severity
              </label>
              <select className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="CRITICAL">Critical</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Action Taken
              </label>
              <textarea
                placeholder="What actions have been taken..."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="rounded-lg bg-amber-500 px-4 py-2 text-white hover:bg-amber-600"
              >
                Submit Report
              </button>
              <button
                type="button"
                onClick={() => setShowNewForm(false)}
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="rounded-lg bg-white shadow dark:bg-gray-800">
        <div className="border-b border-gray-200 p-4 dark:border-gray-700">
          <div className="flex gap-2">
            {["", "LOW", "MEDIUM", "HIGH", "CRITICAL"].map((sev) => (
              <button
                key={sev}
                onClick={() => {
                  setFilter(sev)
                  setPage(1)
                }}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                  filter === sev
                    ? "bg-amber-500 text-white"
                    : "bg-gray-100 text-gray-900 hover:bg-gray-200 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
                }`}
              >
                {sev || "All"}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Title
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Severity
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Date
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-900 dark:text-white">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {incidents.map((incident) => (
                <tr key={incident.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
                    {incident.title}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    {incident.client.firstName} {incident.client.lastName}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                        severityColors[incident.severity]
                      }`}
                    >
                      {incident.severity}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                        incident.resolved
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                          : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                      }`}
                    >
                      {incident.resolved ? "Resolved" : "Unresolved"}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-400">
                    {new Date(incident.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button className="text-blue-600 hover:text-blue-800 dark:text-blue-400">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(incident.id)}
                        className="text-red-600 hover:text-red-800 dark:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
