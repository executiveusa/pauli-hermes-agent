"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Plus, Edit2, Trash2, Eye } from "lucide-react"
import { Button } from "@/components/ui"

interface CareNote {
  id: string
  content: string
  category: string
  mood: string
  client: { firstName: string; lastName: string }
  caregiver: { firstName: string; lastName: string }
  shift: { id: string }
  createdAt: string
}

export default function CareNotesPage() {
  const { data: session } = useSession()
  const [careNotes, setCareNotes] = useState<CareNote[]>([])
  const [loading, setLoading] = useState(true)
  const [showNewForm, setShowNewForm] = useState(false)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState("")

  useEffect(() => {
    const fetchCareNotes = async () => {
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: "20",
          search,
        })
        const response = await fetch(`/api/carenotes?${params}`)
        if (response.ok) {
          const data = await response.json()
          setCareNotes(data.data)
        }
      } catch (error) {
        console.error("Error fetching care notes:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchCareNotes()
    }
  }, [session, page, search])

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this care note?")) {
      try {
        const response = await fetch(`/api/carenotes/${id}`, {
          method: "DELETE",
        })
        if (response.ok) {
          setCareNotes(careNotes.filter((note) => note.id !== id))
        }
      } catch (error) {
        console.error("Error deleting care note:", error)
      }
    }
  }

  if (loading) {
    return <div>Loading care notes...</div>
  }

  const categories = ["GENERAL", "MEDICATION", "MEAL", "ACTIVITY", "HYGIENE", "HEALTH", "BEHAVIORAL"]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Care Notes
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage daily care documentation and observations
          </p>
        </div>
        <Button
          variant="premium"
          onClick={() => setShowNewForm(!showNewForm)}
          className="gap-2"
        >
          <Plus className="h-5 w-5" />
          Add Note
        </Button>
      </div>

      {showNewForm && (
        <div className="rounded-lg bg-white p-6 shadow dark:bg-gray-800">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            New Care Note
          </h2>
          <form className="mt-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Category
              </label>
              <select className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white">
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Content
              </label>
              <textarea
                placeholder="Document observations, activities, medications administered..."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                rows={4}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Mood
              </label>
              <input
                type="text"
                placeholder="Happy, Anxious, Quiet, etc."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="rounded-lg bg-amber-500 px-4 py-2 text-white hover:bg-amber-600"
              >
                Save Care Note
              </button>
              <button
                type="button"
                onClick={() => setShowNewForm(false)}
                className="rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="rounded-lg bg-white shadow dark:bg-gray-800">
        <div className="border-b border-gray-200 p-4 dark:border-gray-700">
          <input
            type="text"
            placeholder="Search care notes..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value)
              setPage(1)
            }}
            className="w-full rounded-lg border border-gray-300 px-4 py-2 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Caregiver
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Mood
                </th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                  Date
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-gray-900 dark:text-white">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {careNotes.map((note) => (
                <tr key={note.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    {note.client.firstName} {note.client.lastName}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    {note.caregiver.firstName} {note.caregiver.lastName}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span className="inline-block rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                      {note.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    {note.mood || "-"}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-400">
                    {new Date(note.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => {}}
                        className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => {}}
                        className="text-gray-600 hover:text-gray-800 dark:text-gray-400"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(note.id)}
                        className="text-red-600 hover:text-red-800 dark:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
