"use client"

import { ReactNode } from "react"
import { useSession, signOut } from "next-auth/react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { LayoutDashboard, Users, ClipboardList, FileText, LogOut, Menu } from "lucide-react"
import { Button } from "@/components/ui"
import { useState } from "react"

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  if (status === "loading") {
    return <div className="flex min-h-screen items-center justify-center">Loading...</div>
  }

  if (status === "unauthenticated") {
    router.push("/login")
    return null
  }

  const menuItems = [
    { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/dashboard/clients", icon: Users, label: "Clients" },
    { href: "/dashboard/caregivers", icon: Users, label: "Caregivers" },
    { href: "/dashboard/shifts", icon: ClipboardList, label: "Shifts" },
    { href: "/dashboard/invoices", icon: FileText, label: "Invoices" },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 z-40 h-screen bg-gray-900 text-white transition-all duration-300 ${
          sidebarOpen ? "w-64" : "w-20"
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b border-gray-800 px-4">
          {sidebarOpen && <h1 className="text-xl font-bold">Golden Hearts</h1>}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="rounded-lg p-2 hover:bg-gray-800"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>

        <nav className="space-y-2 px-4 py-8">
          {menuItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-4 rounded-lg px-4 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <item.icon className="h-5 w-5" />
              {sidebarOpen && <span>{item.label}</span>}
            </Link>
          ))}
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <Button
            variant="outline"
            className="w-full justify-start gap-4 border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
            onClick={() => signOut({ redirect: true, callbackUrl: "/" })}
          >
            <LogOut className="h-5 w-5" />
            {sidebarOpen && "Logout"}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-20"} flex-1`}>
        {/* Top Bar */}
        <div className="border-b border-gray-200 bg-white px-8 py-4 dark:border-gray-800 dark:bg-gray-800">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              {session?.user?.name || "Dashboard"}
            </h2>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {session?.user?.email}
            </div>
          </div>
        </div>

        {/* Page Content */}
        <div className="p-8">{children}</div>
      </main>
    </div>
  )
}
