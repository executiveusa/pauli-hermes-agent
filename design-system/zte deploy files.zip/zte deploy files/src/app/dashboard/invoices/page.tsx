"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Plus, Download, Eye } from "lucide-react"
import { Button } from "@/components/ui"
import { format } from "date-fns"

interface Invoice {
  id: string
  invoiceNumber: string
  client: { firstName: string; lastName: string }
  periodStart: string
  periodEnd: string
  total: number
  amountPaid: number
  status: string
}

export default function InvoicesPage() {
  const { data: session } = useSession()
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const response = await fetch("/api/invoices")
        if (response.ok) {
          const data = await response.json()
          setInvoices(data)
        }
      } catch (error) {
        console.error("Error fetching invoices:", error)
      } finally {
        setLoading(false)
      }
    }

    if (session) {
      fetchInvoices()
    }
  }, [session])

  if (loading) {
    return <div>Loading invoices...</div>
  }

  const statusColors: Record<string, string> = {
    DRAFT: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-400",
    SENT: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
    PAID: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    PARTIAL:
      "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    OVERDUE: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Invoices
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage billing and payments
          </p>
        </div>
        <Button variant="premium" className="gap-2">
          <Plus className="h-5 w-5" />
          Create Invoice
        </Button>
      </div>

      {/* Invoices Table */}
      <div className="overflow-x-auto rounded-lg bg-white shadow dark:bg-gray-800">
        <table className="w-full">
          <thead className="border-b border-gray-200 dark:border-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Invoice #
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Client
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Period
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Total
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Paid
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Status
              </th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr
                key={invoice.id}
                className="border-b border-gray-200 dark:border-gray-700"
              >
                <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">
                  {invoice.invoiceNumber}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {invoice.client.firstName} {invoice.client.lastName}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  {format(new Date(invoice.periodStart), "MMM dd, yyyy")} -{" "}
                  {format(new Date(invoice.periodEnd), "MMM dd, yyyy")}
                </td>
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                  ${(invoice.total / 100).toFixed(2)}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                  ${(invoice.amountPaid / 100).toFixed(2)}
                </td>
                <td className="px-6 py-4">
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${
                      statusColors[invoice.status] || statusColors.DRAFT
                    }`}
                  >
                    {invoice.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button className="text-blue-600 hover:text-blue-800 dark:text-blue-400">
                      <Eye className="h-5 w-5" />
                    </button>
                    <button className="text-green-600 hover:text-green-800 dark:text-green-400">
                      <Download className="h-5 w-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {invoices.length === 0 && (
        <div className="rounded-lg bg-white p-12 text-center shadow dark:bg-gray-800">
          <p className="text-gray-600 dark:text-gray-400">
            No invoices yet. Create your first invoice to get started.
          </p>
        </div>
      )}
    </div>
  )
}
