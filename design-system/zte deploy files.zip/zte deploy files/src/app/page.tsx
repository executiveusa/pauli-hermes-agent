﻿import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Golden Hearts Home Care - Premium Senior Care in Scottsdale, Arizona',
  description: 'Licensed in-home care in Scottsdale, Chandler, Paradise Valley. Personalized, premium senior care with a trusted local caregiver. 24/7 available.',
  keywords: ['senior care', 'in-home care', 'Scottsdale', 'caregiver', 'eldercare', 'memory care'],
  openGraph: {
    title: 'Golden Hearts Home Care - Premium Senior Care in Scottsdale',
    description: 'Personalized in-home care for seniors. Licensed, bonded, and genuinely committed.',
    url: 'https://goldenhearts.care',
    type: 'website',
  },
};

export default function Home() {
  return (
    <>
      {/* HEADER */}
      <header className="sticky top-0 bg-[#FEFDFB] border-b border-[#E8DFD5] backdrop-blur-md z-50">
        <nav className="max-w-6xl mx-auto px-4 md:px-8 py-4 md:py-5 flex justify-between items-center">
          <a href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <svg className="w-10 h-10" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="heartGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor:'#D4AF8A',stopOpacity:1}} />
                  <stop offset="50%" style={{stopColor:'#C9896D',stopOpacity:1}} />
                  <stop offset="100%" style={{stopColor:'#8B7355',stopOpacity:1}} />
                </linearGradient>
                <linearGradient id="accentGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor:'#C9896D',stopOpacity:1}} />
                  <stop offset="100%" style={{stopColor:'#8B7355',stopOpacity:1}} />
                </linearGradient>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              <circle cx="100" cy="100" r="95" fill="none" stroke="#D4AF8A" strokeWidth="1" opacity="0.2"/>
              <path d="M 100 165 C 45 130 20 105 20 75 C 20 50 38 35 55 35 C 68 35 80 42 100 58 C 120 42 132 35 145 35 C 162 35 180 50 180 75 C 180 105 155 130 100 165 Z" 
                    fill="url(#heartGradient)" 
                    filter="url(#glow)"
                    stroke="#8B7355" 
                    strokeWidth="1.5"
                    opacity="0.95"/>
              <ellipse cx="65" cy="65" rx="8" ry="12" fill="url(#accentGradient)" opacity="0.7"/>
              <ellipse cx="65" cy="65" rx="5" ry="8" fill="#FEFDFB" opacity="0.4"/>
              <ellipse cx="130" cy="85" rx="6" ry="10" fill="url(#accentGradient)" opacity="0.6"/>
              <ellipse cx="130" cy="85" rx="3" ry="6" fill="#FEFDFB" opacity="0.3"/>
              <ellipse cx="100" cy="85" rx="10" ry="15" fill="#FEFDFB" opacity="0.15"/>
            </svg>
            <span className="text-lg md:text-xl font-semibold text-[#8B7355] tracking-tighter hidden sm:inline">
              Golden Hearts
            </span>
          </a>
          <ul className="hidden md:flex gap-10 items-center">
            <li><a href="#about" className="text-[#2C2420] font-medium hover:text-[#C9896D] transition-colors">About</a></li>
            <li><a href="#services" className="text-[#2C2420] font-medium hover:text-[#C9896D] transition-colors">Services</a></li>
            <li><a href="#pricing" className="text-[#2C2420] font-medium hover:text-[#C9896D] transition-colors">Pricing</a></li>
            <li><a href="#how" className="text-[#2C2420] font-medium hover:text-[#C9896D] transition-colors">How It Works</a></li>
            <li>
              <a href="#contact" className="bg-[#8B7355] text-white px-7 py-3 rounded hover:bg-[#2C2420] transition-all font-semibold text-sm min-h-[44px] flex items-center">
                Schedule Consultation
              </a>
            </li>
          </ul>
          {/* Mobile menu toggle button */}
          <button className="md:hidden text-[#8B7355] text-2xl font-bold">☰</button>
        </nav>
      </header>

      {/* HERO SECTION */}
      <section className="max-w-6xl mx-auto px-8 py-20 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="animate-in fade-in duration-800">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-serif font-semibold text-[#2C2420] leading-tight mb-6">
            I'm Here For Your Loved One
          </h1>
          <p className="text-xl text-[#2C2420] font-medium mb-6 leading-relaxed">
            Premium, personalized care in Scottsdale. No agency overhead. Just me — a licensed caregiver who genuinely cares.
          </p>
          <p className="text-lg text-gray-600 mb-6 leading-relaxed">
            Serving Scottsdale, Chandler, Paradise Valley, and the greater Phoenix area with white-glove in-home care.
          </p>

          <div className="flex flex-wrap gap-4 mb-8">
            <div className="flex items-center gap-2 text-sm text-[#8B7355] bg-[rgba(139,115,85,0.08)] px-4 py-2 rounded border border-[#D4AF8A]">
              <span className="font-bold">✓</span>
              <span className="font-medium">Arizona Licensed</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-[#8B7355] bg-[rgba(139,115,85,0.08)] px-4 py-2 rounded border border-[#D4AF8A]">
              <span className="font-bold">✓</span>
              <span className="font-medium">Bonded & Insured</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-[#8B7355] bg-[rgba(139,115,85,0.08)] px-4 py-2 rounded border border-[#D4AF8A]">
              <span className="font-bold">✓</span>
              <span className="font-medium">24/7 Available</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-[#8B7355] bg-[rgba(139,115,85,0.08)] px-4 py-2 rounded border border-[#D4AF8A]">
              <span className="font-bold">✓</span>
              <span className="font-medium">15+ Years Experience</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <button className="bg-[#8B7355] text-white px-10 py-3 md:py-4 rounded min-h-12 font-semibold hover:bg-[#2C2420] transition-all hover:shadow-lg">
              Schedule Consultation
            </button>
            <a href="tel:+16025750536" className="text-[#8B7355] font-semibold text-lg hover:text-[#C9896D] transition-colors">
              ☎ (602) 575-0536
            </a>
          </div>
        </div>

        <div className="relative animate-in fade-in slide-in-from-right duration-800 delay-200">
          <Image
            src="https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=600&h=700&fit=crop"
            alt="Premium home care in Scottsdale"
            width={500}
            height={600}
            priority
            className="rounded-lg shadow-2xl max-h-[50vh] md:max-h-none object-cover"
          />
          <div className="absolute top-5 right-5 bg-white/95 backdrop-blur-md p-6 rounded-lg shadow-lg max-w-xs">
            <h3 className="text-2xl font-serif text-[#2C2420] mb-1">Available Now</h3>
            <p className="text-[#C9896D] font-semibold mb-2">Free Consultation</p>
            <p className="text-sm text-gray-600 leading-relaxed">
              No obligation. No pressure. Just a conversation about what you need.
            </p>
          </div>
        </div>
      </section>

      {/* ABOUT SECTION */}
      <section id="about" className="bg-[#F5F1ED] py-24 mt-8">
        <div className="max-w-6xl mx-auto px-8 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="animate-in fade-in slide-in-from-left duration-800">
            <Image
              src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&h=600&fit=crop"
              alt="About the caregiver"
              width={500}
              height={500}
              className="rounded-lg"
            />
          </div>
          <div className="animate-in fade-in duration-800 delay-200">
            <h2 className="text-3xl md:text-5xl font-serif text-[#2C2420] mb-6">Why Choose Me?</h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              I became a caregiver because I believe every senior deserves dignity, respect, and genuine attention. This isn't a job to me — it's a calling. I specialize in helping families navigate the most important decision they'll make about their loved one's care.
            </p>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              After 15 years in senior care, I chose to go solo. Why? Because I wanted complete control over quality, consistency, and the personal touch that separates care from companionship. When you work with me, you're not dealing with a corporation. You're working with someone who will show up, listen, and truly care.
            </p>

            <div className="bg-white p-6 rounded-lg border-l-4 border-[#C9896D] mt-8">
              <h3 className="text-lg text-[#8B7355] mb-4 font-semibold">My Credentials & Specializations</h3>
              <ul className="space-y-3">
                <li className="text-gray-600 flex items-center gap-2">
                  <span className="text-[#C9896D] font-bold text-xl">→</span>
                  Arizona State Licensed Caregiver
                </li>
                <li className="text-gray-600 flex items-center gap-2">
                  <span className="text-[#C9896D] font-bold text-xl">→</span>
                  Certified Dementia Care Specialist
                </li>
                <li className="text-gray-600 flex items-center gap-2">
                  <span className="text-[#C9896D] font-bold text-xl">→</span>
                  Advanced Training in Alzheimer's & Memory Care
                </li>
                <li className="text-gray-600 flex items-center gap-2">
                  <span className="text-[#C9896D] font-bold text-xl">→</span>
                  CPR & First Aid Certification (Current)
                </li>
                <li className="text-gray-600 flex items-center gap-2">
                  <span className="text-[#C9896D] font-bold text-xl">→</span>
                  Background Verified & Bonded
                </li>
                <li className="text-gray-600 flex items-center gap-2">
                  <span className="text-[#C9896D] font-bold text-xl">→</span>
                  15+ Years Professional Experience
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES SECTION */}
      <section id="services" className="max-w-6xl mx-auto px-8 py-24 mt-8">
        <div className="text-center mb-16 animate-in fade-in duration-800">
          <h2 className="text-3xl md:text-5xl font-serif text-[#2C2420] mb-4">What I Provide</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive, personalized care tailored to your loved one's unique needs — delivered with professionalism and genuine warmth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-800 delay-200">
          {[
            {
              icon: 'ðŸ›',
              title: 'Personal Care',
              description: 'Help with bathing, dressing, grooming, toileting, and mobility assistance. Always with dignity and respect for privacy.',
              details: 'ADLs, medication reminders, hygiene support, mobility assistance, safe home navigation'
            },
            {
              icon: 'ðŸ¤',
              title: 'Companion Care',
              description: 'Meaningful conversation, outings, hobbies, meal prep, light housekeeping, and emotional support. Real companionship.',
              details: 'Social activities, appointments, shopping, errands, cooking, conversation, hobby support'
            },
            {
              icon: 'ðŸŒ™',
              title: '24/7 Live-In Care',
              description: 'Around-the-clock presence and support for families who need consistent, reliable care through nights and weekends.',
              details: 'Overnight monitoring, 24-hour availability, medication management, emergency response, peace of mind'
            },
            {
              icon: 'ðŸ§ ',
              title: 'Memory Care Specialist',
              description: 'Specialized care for dementia, Alzheimer\'s, and Parkinson\'s. Patient, calm, consistent — with proven techniques and empathy.',"
              details: 'Validation therapy, structured routines, behavioral support, family education, compassionate approach'
            }
          ].map((service, idx) => (
            <div
              key={idx}
              className="bg-white p-8 rounded-lg border border-[#E8DFD5] hover:border-[#C9896D] hover:shadow-lg transition-all"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-2xl text-[#8B7355] mb-3 font-semibold">{service.title}</h3>
              <p className="text-gray-600 mb-4 leading-relaxed">{service.description}</p>
              <div className="bg-[#F5F1ED] p-4 rounded text-sm text-[#2C2420]">
                <strong className="text-[#8B7355]">Includes:</strong><br />
                {service.details}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING SECTION */}
      <section id="pricing" className="bg-[#F5F1ED] py-24">
        <div className="max-w-6xl mx-auto px-8">
          <div className="text-center mb-16 animate-in fade-in duration-800">
            <h2 className="text-3xl md:text-5xl font-serif text-[#2C2420] mb-4">Transparent Pricing</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              No agency markup. No hidden fees. Just honest, clear pricing for the care you need.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 animate-in fade-in duration-800 delay-200">
            {[
              {
                title: 'Personal Care',
                price: '$28',
                period: '/hr',
                note: '4-hour minimum | Flexible scheduling',
                items: ['Bathing & grooming', 'Dressing & mobility help', 'Medication reminders', 'Light housekeeping', 'Appointment coordination']
              },
              {
                title: 'Companion Care',
                price: '$24',
                period: '/hr',
                note: 'Flexible hourly | As-needed scheduling',
                items: ['Outings & activities', 'Conversation & companionship', 'Shopping & errands', 'Meal preparation', 'Light cleaning']
              },
              {
                title: '24/7 Live-In Care',
                price: '$200',
                period: '/night',
                note: 'Full-time arrangements | Month-to-month',
                items: ['24-hour on-site presence', 'Overnight monitoring', 'Meals & household management', 'Emergency response', 'Full personal care']
              },
              {
                title: 'Memory Care',
                price: '$32',
                period: '/hr',
                note: 'Specialized care | Custom arrangements',
                items: ['Dementia/Alzheimer\'s expertise', 'Validation therapy techniques', 'Behavioral support', 'Family education & resources', 'Compassionate approach']
              }
            ].map((plan, idx) => (
              <div key={idx} className="bg-white p-8 rounded-lg border-2 border-[#E8DFD5] hover:border-[#C9896D] hover:shadow-lg transition-all">
                <h3 className="text-2xl text-[#8B7355] mb-2 font-semibold">{plan.title}</h3>
                <div className="text-5xl text-[#2C2420] font-serif font-bold mb-1">
                  {plan.price}<span className="text-sm font-semibold ml-1">{plan.period}</span>
                </div>
                <p className="text-gray-500 text-sm mb-6">{plan.note}</p>
                <ul className="space-y-3">
                  {plan.items.map((item, i) => (
                    <li key={i} className="text-gray-600 flex items-center gap-3 text-sm pb-3 border-b border-[#E8DFD5] last:border-0">
                      <span className="text-[#C9896D] font-bold text-lg">â€¢</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="text-center text-gray-600 text-sm py-6 border-t border-[#E8DFD5] mt-8">
            <strong className="text-[#2C2420]">First consultation is complimentary.</strong> We'll discuss your needs, my approach, and answer any questions. No obligation.
          </div>
        </div>
      </section>

      {/* TESTIMONIALS SECTION */}
      <section id="testimonials" className="max-w-6xl mx-auto px-8 py-24">
        <div className="text-center mb-16 animate-in fade-in duration-800">
          <h2 className="text-3xl md:text-5xl font-serif text-[#2C2420] mb-4">Trusted By Families</h2>
          <p className="text-xl text-gray-600">Here's what real families have to say about working with me.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-800 delay-200">
          {[
            {
              quote: 'My mother\'s Alzheimer\'s was progressing, and I was terrified of leaving her with someone new. From day one, she felt comfortable — and that made me feel secure. The consistency, the warmth, the genuine care... I can\'t recommend enough.',
              author: 'Sarah Morrison',
              role: 'Daughter of Client',
              initials: 'SM'
            },
            {
              quote: 'As a physician, I refer my patients without hesitation. The professionalism, the respect for boundaries, the communication with family — it\'s exactly what quality care should look like. A true partner in health.',
              author: 'Dr. Robert Chen',
              role: 'Internist, Scottsdale',
              initials: 'DC'
            },
            {
              quote: 'I was nervous about having someone in my home. But from the first visit, I felt at ease. She listens, she respects my independence, and she\'s genuinely interested in what I care about. Not just care — real companionship.',
              author: 'Patricia Williams',
              role: 'Golden Hearts Client',
              initials: 'PW'
            },
            {
              quote: 'We needed someone fast. The consistency alone has been transformative. Dad has a routine, a person he trusts, and I sleep soundly knowing he\'s genuinely cared for — not just supervised. Worth every penny.',
              author: 'James Turner',
              role: 'Son of Client',
              initials: 'JT'
            }
          ].map((testimonial, idx) => (
            <div key={idx} className="bg-white p-8 rounded-lg border border-[#E8DFD5] hover:shadow-lg transition-all">
              <div className="text-4xl text-[#C9896D] mb-4">"</div>
              <p className="text-gray-600 italic mb-6 leading-relaxed">{testimonial.quote}</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#8B7355] to-[#C9896D] flex items-center justify-center text-white font-bold text-sm">
                  {testimonial.initials}
                </div>
                <div>
                  <h4 className="font-semibold text-[#2C2420]">{testimonial.author}</h4>
                  <p className="text-sm text-[#C9896D] font-medium">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="bg-[#F5F1ED] py-24">
        <div className="max-w-4xl mx-auto px-8">
          <div className="text-center mb-16 animate-in fade-in duration-800">
            <h2 className="text-3xl md:text-5xl font-serif text-[#2C2420] mb-4">How We Get Started</h2>
            <p className="text-xl text-gray-600">A simple, personal process designed around your needs — not mine.</p>
          </div>

          <div className="space-y-8 animate-in fade-in duration-800 delay-200">
            {[
              {
                num: '1',
                title: 'You Call or Schedule',
                desc: 'Reach out at (602) 575-0536 or schedule a consultation online. No pressure. Just a conversation to see if we\'re a good fit and to understand what you need.'
              },
              {
                num: '2',
                title: 'We Meet & Listen',
                desc: 'I come to your home (at a time that works for you) and meet your loved one in their own environment. I listen deeply — to their needs, preferences, concerns, and your family\'s priorities.'
              },
              {
                num: '3',
                title: 'We Create a Plan',
                desc: 'Based on everything I learn, we design a customized care approach — schedule, services, preferences, medical needs. Nothing generic. Everything tailored to your situation.'
              },
              {
                num: '4',
                title: 'Care Begins',
                desc: 'I show up, do the work, and stay available. You always have my direct number. We adjust as needs change. That\'s it — simple, reliable, human.'
              }
            ].map((step, idx) => (
              <div key={idx} className="flex gap-8 items-start">
                <div className="w-20 h-20 rounded-full bg-[#8B7355] text-white flex items-center justify-center font-serif font-bold text-4xl flex-shrink-0">
                  {step.num}
                </div>
                <div className="flex-1 pt-2">
                  <h3 className="text-2xl text-[#2C2420] mb-3 font-semibold">{step.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section id="contact" className="max-w-6xl mx-auto px-8 py-24">
        <div className="bg-gradient-to-br from-[#8B7355] to-[#C9896D] text-white p-16 rounded-lg text-center animate-in fade-in duration-800">
          <h2 className="text-5xl font-serif mb-4">Ready to Have a Conversation?</h2>
          <p className="text-xl mb-8 opacity-95">
            Schedule a free, no-obligation consultation. Let's talk about what's best for your family.
          </p>
          <button className="bg-white text-[#8B7355] px-12 py-4 rounded font-bold text-lg hover:bg-[#F5F1ED] transition-all shadow-lg hover:shadow-xl ">
            Schedule Now
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#2C2420] text-white py-12 mt-24">
        <div className="max-w-6xl mx-auto px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-8">
            <div>
              <h4 className="text-lg text-[#D4AF8A] mb-4 font-semibold">Golden Hearts Home Care</h4>
              <p className="text-opacity-80 text-white leading-relaxed">
                Premium, personalized senior care in Scottsdale. Licensed, bonded, and genuinely committed to your loved one's wellbeing.
              </p>
            </div>
            <div>
              <h4 className="text-lg text-[#D4AF8A] mb-4 font-semibold">Services</h4>
              <ul className="space-y-2 text-opacity-80 text-white">
                <li><a href="#services" className="hover:text-[#D4AF8A] transition-colors">Personal Care</a></li>
                <li><a href="#services" className="hover:text-[#D4AF8A] transition-colors">Companion Care</a></li>
                <li><a href="#services" className="hover:text-[#D4AF8A] transition-colors">24/7 Live-In Care</a></li>
                <li><a href="#services" className="hover:text-[#D4AF8A] transition-colors">Memory Care Specialist</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg text-[#D4AF8A] mb-4 font-semibold">Contact</h4>
              <p className="text-opacity-80 text-white mb-2"><a href="tel:+16025750536" className="hover:text-[#D4AF8A] transition-colors">(602) 575-0536</a></p>
              <p className="text-opacity-80 text-white mb-2">Scottsdale, AZ 85260</p>
              <p className="text-opacity-80 text-white"><a href="mailto:hello@goldenhearts.care" className="hover:text-[#D4AF8A] transition-colors">hello@goldenhearts.care</a></p>
            </div>
          </div>
          <div className="border-t border-white border-opacity-10 pt-8 text-center text-opacity-60 text-white text-sm">
            <p>Â© 2026 Golden Hearts Home Care. Arizona State Licensed. Bonded & Insured. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* SMOOTH SCROLL SCRIPT */}
      <script dangerouslySetInnerHTML={{
        __html: `
          document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
              e.preventDefault();
              const target = document.querySelector(this.getAttribute('href'));
              if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }
            });
          });

          document.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', function() {
              const href = this.getAttribute('href');
              if (href?.startsWith('#')) {
                return;
              }
              console.log('Booking button clicked - integrate with your booking system');
            });
          });
        `
      }} />
    </>
  );
}


