import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { updatePayoutSchema } from "@/lib/validations"

// GET - Get payout by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const payout = await prisma.payout.findUnique({
      where: { id: params.id },
      include: {
        caregiver: true,
      },
    })

    if (!payout) {
      return NextResponse.json(
        { error: "Payout not found" },
        { status: 404 }
      )
    }

    // Check authorization
    if (payout.caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    return NextResponse.json(payout, { status: 200 })
  } catch (error) {
    console.error("Error fetching payout:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// PATCH - Update payout
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingPayout = await prisma.payout.findUnique({
      where: { id: params.id },
      include: { caregiver: true },
    })

    if (!existingPayout) {
      return NextResponse.json(
        { error: "Payout not found" },
        { status: 404 }
      )
    }

    if (existingPayout.caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    const body = await request.json()
    const validatedData = updatePayoutSchema.parse(body)

    // Add paidAt timestamp when status changes to PAID
    const dataToUpdate: Record<string, unknown> = { ...validatedData }
    if (validatedData.status === "PAID" && existingPayout.paidAt === null) {
      dataToUpdate.paidAt = new Date()
    }

    const payout = await prisma.payout.update({
      where: { id: params.id },
      data: dataToUpdate,
      include: {
        caregiver: true,
      },
    })

    return NextResponse.json(payout, { status: 200 })
  } catch (error: any) {
    console.error("Error updating payout:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// DELETE - Delete payout
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingPayout = await prisma.payout.findUnique({
      where: { id: params.id },
      include: { caregiver: true },
    })

    if (!existingPayout) {
      return NextResponse.json(
        { error: "Payout not found" },
        { status: 404 }
      )
    }

    if (existingPayout.caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    await prisma.payout.delete({
      where: { id: params.id },
    })

    return NextResponse.json(
      { message: "Payout deleted successfully" },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error deleting payout:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
