import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { createPayoutSchema } from "@/lib/validations"

// GET - List payouts with pagination, filtering, and sorting
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Parse query parameters
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "20")
    const sortBy = searchParams.get("sortBy") || "createdAt"
    const sortOrder = (searchParams.get("sortOrder") || "desc") as "asc" | "desc"
    const caregiverId = searchParams.get("caregiverId")
    const status = searchParams.get("status")

    const skip = (page - 1) * limit

    // Build filter
    const where: any = {
      caregiver: {
        organizationId: user.organizationId,
      },
    }

    if (caregiverId) where.caregiverId = caregiverId
    if (status) where.status = status

    // Build sort
    const orderBy: any = {}
    orderBy[sortBy] = sortOrder

    const [payouts, total] = await Promise.all([
      prisma.payout.findMany({
        where,
        include: {
          caregiver: true,
        },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.payout.count({ where }),
    ])

    return NextResponse.json(
      {
        data: payouts,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error fetching payouts:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// POST - Create payout
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const body = await request.json()
    const validatedData = createPayoutSchema.parse(body)

    // Verify caregiver belongs to this organization
    const caregiver = await prisma.caregiver.findUnique({
      where: { id: validatedData.caregiverId },
    })

    if (!caregiver || caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Caregiver not found or unauthorized" },
        { status: 404 }
      )
    }

    const payout = await prisma.payout.create({
      data: validatedData,
      include: {
        caregiver: true,
      },
    })

    return NextResponse.json(payout, { status: 201 })
  } catch (error: any) {
    console.error("Error creating payout:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
