import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { updateCareNoteSchema } from "@/lib/validations"

// GET - Get care note by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const careNote = await prisma.careNote.findUnique({
      where: { id: params.id },
      include: {
        shift: true,
        client: true,
        caregiver: true,
      },
    })

    if (!careNote) {
      return NextResponse.json(
        { error: "Care note not found" },
        { status: 404 }
      )
    }

    // Check authorization
    if (careNote.shift.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    return NextResponse.json(careNote, { status: 200 })
  } catch (error) {
    console.error("Error fetching care note:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// PATCH - Update care note
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Check if care note exists and belongs to this organization
    const existingCareNote = await prisma.careNote.findUnique({
      where: { id: params.id },
      include: { shift: true },
    })

    if (!existingCareNote) {
      return NextResponse.json(
        { error: "Care note not found" },
        { status: 404 }
      )
    }

    if (existingCareNote.shift.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    const body = await request.json()
    const validatedData = updateCareNoteSchema.parse(body)

    const careNote = await prisma.careNote.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        shift: true,
        client: true,
        caregiver: true,
      },
    })

    return NextResponse.json(careNote, { status: 200 })
  } catch (error: any) {
    console.error("Error updating care note:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// DELETE - Delete care note
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingCareNote = await prisma.careNote.findUnique({
      where: { id: params.id },
      include: { shift: true },
    })

    if (!existingCareNote) {
      return NextResponse.json(
        { error: "Care note not found" },
        { status: 404 }
      )
    }

    if (existingCareNote.shift.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    await prisma.careNote.delete({
      where: { id: params.id },
    })

    return NextResponse.json(
      { message: "Care note deleted successfully" },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error deleting care note:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
