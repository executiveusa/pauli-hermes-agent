import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { createCareNoteSchema, paginationSchema } from "@/lib/validations"

// GET - List care notes with pagination, filtering, and sorting
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user organization
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Parse query parameters
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "20")
    const search = searchParams.get("search") || ""
    const sortBy = searchParams.get("sortBy") || "createdAt"
    const sortOrder = (searchParams.get("sortOrder") || "desc") as "asc" | "desc"
    const clientId = searchParams.get("clientId")
    const caregiverId = searchParams.get("caregiverId")
    const shiftId = searchParams.get("shiftId")
    const category = searchParams.get("category")

    const skip = (page - 1) * limit

    // Build filter
    const where: any = {
      shift: {
        organizationId: user.organizationId,
      },
    }

    if (clientId) where.clientId = clientId
    if (caregiverId) where.caregiverId = caregiverId
    if (shiftId) where.shiftId = shiftId
    if (category) where.category = category

    // Build search filter
    if (search) {
      where.OR = [
        { content: { contains: search, mode: "insensitive" } },
        { mood: { contains: search, mode: "insensitive" } },
      ]
    }

    // Build sort
    const orderBy: any = {}
    if (sortBy === "content" || sortBy === "category" || sortBy === "mood") {
      orderBy[sortBy] = sortOrder
    } else {
      orderBy[sortBy] = sortOrder
    }

    const [careNotes, total] = await Promise.all([
      prisma.careNote.findMany({
        where,
        include: {
          shift: true,
          client: true,
          caregiver: true,
        },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.careNote.count({ where }),
    ])

    return NextResponse.json(
      {
        data: careNotes,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error fetching care notes:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// POST - Create care note
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const body = await request.json()

    // Validate request body
    const validatedData = createCareNoteSchema.parse(body)

    // Verify the shift belongs to this organization
    const shift = await prisma.shift.findUnique({
      where: { id: validatedData.shiftId },
    })

    if (!shift || shift.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Shift not found or unauthorized" },
        { status: 404 }
      )
    }

    // Verify client belongs to this organization
    const client = await prisma.client.findUnique({
      where: { id: validatedData.clientId },
    })

    if (!client || client.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Client not found or unauthorized" },
        { status: 404 }
      )
    }

    // Verify caregiver belongs to this organization
    const caregiver = await prisma.caregiver.findUnique({
      where: { id: validatedData.caregiverId },
    })

    if (!caregiver || caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Caregiver not found or unauthorized" },
        { status: 404 }
      )
    }

    const careNote = await prisma.careNote.create({
      data: validatedData,
      include: {
        shift: true,
        client: true,
        caregiver: true,
      },
    })

    return NextResponse.json(careNote, { status: 201 })
  } catch (error: any) {
    console.error("Error creating care note:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
