import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { updateCaregiverSchema } from "@/lib/validations"

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const caregiver = await prisma.caregiver.findUnique({
      where: { id: params.id },
      include: {
        shifts: true,
        payouts: true,
        careNotes: true,
        incidents: true,
      },
    })

    if (!caregiver) {
      return NextResponse.json(
        { error: "Caregiver not found" },
        { status: 404 }
      )
    }

    // Check authorization
    if (caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    return NextResponse.json(caregiver)
  } catch (error) {
    console.error("Error fetching caregiver:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingCaregiver = await prisma.caregiver.findUnique({
      where: { id: params.id },
    })

    if (!existingCaregiver) {
      return NextResponse.json(
        { error: "Caregiver not found" },
        { status: 404 }
      )
    }

    // Check authorization
    if (existingCaregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    const data = await request.json()
    const validatedData = updateCaregiverSchema.parse(data)

    const caregiver = await prisma.caregiver.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        shifts: true,
        payouts: true,
      },
    })

    return NextResponse.json(caregiver)
  } catch (error: any) {
    console.error("Error updating caregiver:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingCaregiver = await prisma.caregiver.findUnique({
      where: { id: params.id },
    })

    if (!existingCaregiver) {
      return NextResponse.json(
        { error: "Caregiver not found" },
        { status: 404 }
      )
    }

    // Check authorization
    if (existingCaregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    await prisma.caregiver.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ message: "Caregiver deleted successfully" })
  } catch (error) {
    console.error("Error deleting caregiver:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
