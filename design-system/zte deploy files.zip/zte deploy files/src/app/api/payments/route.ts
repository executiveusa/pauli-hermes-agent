import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
})

// POST - Create Stripe payment intent
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { invoiceId, amount, paymentMethod } = await request.json()

    if (!invoiceId || !amount) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      )
    }

    // Get organization
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user || !user.organization) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    let payment

    if (paymentMethod === "CREDIT_CARD" || !paymentMethod) {
      // Create Stripe payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amount, // amount in cents
        currency: user.organization.currency?.toLowerCase() || "usd",
        description: `Payment for Invoice ${invoiceId}`,
      })

      payment = await prisma.payment.create({
        data: {
          amount,
          method: "CREDIT_CARD",
          stripePaymentId: paymentIntent.id,
          status: "PENDING",
          organizationId: user.organizationId!,
          invoiceId,
        },
      })

      return NextResponse.json(
        {
          payment,
          clientSecret: paymentIntent.client_secret,
        },
        { status: 201 }
      )
    } else {
      // For other payment methods (bank transfer, check, etc.)
      payment = await prisma.payment.create({
        data: {
          amount,
          method: paymentMethod,
          status: "PENDING",
          organizationId: user.organizationId!,
          invoiceId,
        },
      })

      return NextResponse.json(payment, { status: 201 })
    }
  } catch (error) {
    console.error("Error creating payment:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
