import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// Get payment by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payment = await prisma.payment.findUnique({
      where: { id: params.id },
      include: {
        invoice: true,
      },
    })

    if (!payment) {
      return NextResponse.json(
        { error: "Payment not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(payment)
  } catch (error) {
    console.error("Error fetching payment:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// Update payment status
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { status, notes } = await request.json()

    const payment = await prisma.payment.update({
      where: { id: params.id },
      data: {
        status,
        notes,
      },
      include: {
        invoice: true,
      },
    })

    // Update invoice paid amount if payment completed
    if (status === "COMPLETED") {
      const totalPaid = await prisma.payment.aggregate({
        where: { invoiceId: payment.invoiceId, status: "COMPLETED" },
        _sum: { amount: true },
      })

      const invoice = await prisma.invoice.findUnique({
        where: { id: payment.invoiceId },
      })

      if (invoice && totalPaid._sum.amount) {
        const newStatus =
          totalPaid._sum.amount >= invoice.total ? "PAID" : "PARTIAL"
        await prisma.invoice.update({
          where: { id: payment.invoiceId },
          data: {
            amountPaid: totalPaid._sum.amount,
            status: newStatus,
          },
        })
      }
    }

    return NextResponse.json(payment)
  } catch (error) {
    console.error("Error updating payment:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
