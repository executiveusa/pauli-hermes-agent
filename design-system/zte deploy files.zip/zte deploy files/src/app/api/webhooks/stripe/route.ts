import { NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"
import { prisma } from "@/lib/prisma"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
})

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || ""

// POST - Handle Stripe webhooks
export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("stripe-signature")

    if (!signature || !webhookSecret) {
      return NextResponse.json(
        { error: "Missing signature or webhook secret" },
        { status: 400 }
      )
    }

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (error: any) {
      console.error("Webhook signature verification failed:", error.message)
      return NextResponse.json(
        { error: "Invalid signature" },
        { status: 400 }
      )
    }

    // Handle payment_intent.succeeded
    if (event.type === "payment_intent.succeeded") {
      const paymentIntent = event.data.object as Stripe.PaymentIntent

      // Find the payment record by Stripe payment intent ID
      const payment = await prisma.payment.findFirst({
        where: { stripePaymentId: paymentIntent.id },
        include: { invoice: true },
      })

      if (payment) {
        // Update payment status to completed
        await prisma.payment.update({
          where: { id: payment.id },
          data: { status: "COMPLETED" },
        })

        // Calculate total paid
        const totalPaid = await prisma.payment.aggregate({
          where: {
            invoiceId: payment.invoiceId,
            status: "COMPLETED",
          },
          _sum: { amount: true },
        })

        // Update invoice status
        if (totalPaid._sum.amount && payment.invoice) {
          const isPaid = totalPaid._sum.amount >= payment.invoice.total
          const invoiceStatus = isPaid ? "PAID" : "PARTIAL"

          await prisma.invoice.update({
            where: { id: payment.invoiceId },
            data: {
              status: invoiceStatus,
              amountPaid: totalPaid._sum.amount,
            },
          })
        }

        console.log(`Payment ${payment.id} marked as completed`)
      }
    }

    // Handle payment_intent.payment_failed
    if (event.type === "payment_intent.payment_failed") {
      const paymentIntent = event.data.object as Stripe.PaymentIntent

      const payment = await prisma.payment.findFirst({
        where: { stripePaymentId: paymentIntent.id },
      })

      if (payment) {
        await prisma.payment.update({
          where: { id: payment.id },
          data: {
            status: "FAILED",
            notes: paymentIntent.last_payment_error?.message || "Payment failed"
          },
        })

        console.log(`Payment ${payment.id} marked as failed`)
      }
    }

    // Handle charge.refunded
    if (event.type === "charge.refunded") {
      const charge = event.data.object as Stripe.Charge

      if (charge.payment_intent) {
        const payment = await prisma.payment.findFirst({
          where: { stripePaymentId: charge.payment_intent as string },
        })

        if (payment) {
          await prisma.payment.update({
            where: { id: payment.id },
            data: {
              status: "REFUNDED",
              notes: `Refunded amount: ${charge.amount_refunded / 100} cents`
            },
          })

          console.log(`Payment ${payment.id} marked as refunded`)
        }
      }
    }

    return NextResponse.json(
      { received: true },
      { status: 200 }
    )
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
