import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { createShiftSchema } from "@/lib/validations"

// GET all shifts for organization with pagination, search, filter, sort
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Parse query parameters
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "20")
    const sortBy = searchParams.get("sortBy") || "scheduledStart"
    const sortOrder = (searchParams.get("sortOrder") || "desc") as "asc" | "desc"
    const status = searchParams.get("status")
    const clientId = searchParams.get("clientId")
    const caregiverId = searchParams.get("caregiverId")

    const skip = (page - 1) * limit

    // Build filter
    const where: any = {
      organizationId: user.organizationId,
    }

    if (status) where.status = status
    if (clientId) where.clientId = clientId
    if (caregiverId) where.caregiverId = caregiverId

    // Build sort
    const orderBy: any = {}
    orderBy[sortBy] = sortOrder

    const [shifts, total] = await Promise.all([
      prisma.shift.findMany({
        where,
        include: {
          client: true,
          caregiver: true,
          careNotes: true,
        },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.shift.count({ where }),
    ])

    return NextResponse.json({
      data: shifts,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching shifts:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// POST - Create new shift
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const validatedData = createShiftSchema.parse(data)

    // Get user's organization
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user || !user.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Verify client and caregiver exist
    const [client, caregiver] = await Promise.all([
      prisma.client.findUnique({ where: { id: validatedData.clientId } }),
      prisma.caregiver.findUnique({ where: { id: validatedData.caregiverId } }),
    ])

    if (!client || client.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Client not found or unauthorized" },
        { status: 404 }
      )
    }

    if (!caregiver || caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Caregiver not found or unauthorized" },
        { status: 404 }
      )
    }

    const shift = await prisma.shift.create({
      data: {
        ...validatedData,
        organizationId: user.organizationId,
      },
      include: {
        client: true,
        caregiver: true,
        careNotes: true,
      },
    })

    return NextResponse.json(shift, { status: 201 })
  } catch (error: any) {
    console.error("Error creating shift:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
