import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { updateShiftSchema } from "@/lib/validations"

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const shift = await prisma.shift.findUnique({
      where: { id: params.id },
      include: {
        client: true,
        caregiver: true,
        careNotes: true,
        incidents: true,
      },
    })

    if (!shift) {
      return NextResponse.json({ error: "Shift not found" }, { status: 404 })
    }

    // Check authorization
    if (shift.organizationId !== user.organizationId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    return NextResponse.json(shift)
  } catch (error) {
    console.error("Error fetching shift:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingShift = await prisma.shift.findUnique({
      where: { id: params.id },
    })

    if (!existingShift) {
      return NextResponse.json({ error: "Shift not found" }, { status: 404 })
    }

    // Check authorization
    if (existingShift.organizationId !== user.organizationId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const data = await request.json()
    const validatedData = updateShiftSchema.parse(data)

    // Calculate hours and amounts if clockIn/clockOut provided
    const updateData: Record<string, unknown> = { ...validatedData }
    if ((validatedData as any).clockIn && (validatedData as any).clockOut) {
      const hours =
        (new Date((validatedData as any).clockOut).getTime() -
          new Date((validatedData as any).clockIn).getTime()) /
        (1000 * 60 * 60)
      updateData.totalHours = hours
      updateData.totalAmount = Math.round(hours * (validatedData.hourlyRate || 0))
      updateData.caregiverPay = Math.round(hours * (validatedData.caregiverRate || 0))
    }

    const shift = await prisma.shift.update({
      where: { id: params.id },
      data: updateData,
      include: {
        client: true,
        caregiver: true,
      },
    })

    return NextResponse.json(shift)
  } catch (error: any) {
    console.error("Error updating shift:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingShift = await prisma.shift.findUnique({
      where: { id: params.id },
    })

    if (!existingShift) {
      return NextResponse.json({ error: "Shift not found" }, { status: 404 })
    }

    // Check authorization
    if (existingShift.organizationId !== user.organizationId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    await prisma.shift.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ message: "Shift deleted successfully" })
  } catch (error) {
    console.error("Error deleting shift:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
