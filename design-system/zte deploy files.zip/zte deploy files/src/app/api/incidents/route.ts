import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { createIncidentSchema } from "@/lib/validations"

// GET - List incidents with pagination, filtering, and sorting
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Parse query parameters
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "20")
    const search = searchParams.get("search") || ""
    const sortBy = searchParams.get("sortBy") || "createdAt"
    const sortOrder = (searchParams.get("sortOrder") || "desc") as "asc" | "desc"
    const clientId = searchParams.get("clientId")
    const caregiverId = searchParams.get("caregiverId")
    const severity = searchParams.get("severity")
    const resolved = searchParams.get("resolved")

    const skip = (page - 1) * limit

    // Build filter
    const where: any = {
      client: {
        organizationId: user.organizationId,
      },
    }

    if (clientId) where.clientId = clientId
    if (caregiverId) where.caregiverId = caregiverId
    if (severity) where.severity = severity
    if (resolved) where.resolved = resolved === "true"

    // Build search filter
    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
      ]
    }

    // Build sort
    const orderBy: any = {}
    orderBy[sortBy] = sortOrder

    const [incidents, total] = await Promise.all([
      prisma.incident.findMany({
        where,
        include: {
          client: true,
          caregiver: true,
          shift: true,
        },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.incident.count({ where }),
    ])

    return NextResponse.json(
      {
        data: incidents,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error fetching incidents:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// POST - Create incident
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const body = await request.json()
    const validatedData = createIncidentSchema.parse(body)

    // Verify client belongs to this organization
    const client = await prisma.client.findUnique({
      where: { id: validatedData.clientId },
    })

    if (!client || client.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Client not found or unauthorized" },
        { status: 404 }
      )
    }

    // Verify caregiver belongs to this organization
    const caregiver = await prisma.caregiver.findUnique({
      where: { id: validatedData.caregiverId },
    })

    if (!caregiver || caregiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Caregiver not found or unauthorized" },
        { status: 404 }
      )
    }

    // Verify shift if provided
    if (validatedData.shiftId) {
      const shift = await prisma.shift.findUnique({
        where: { id: validatedData.shiftId },
      })

      if (!shift || shift.organizationId !== user.organizationId) {
        return NextResponse.json(
          { error: "Shift not found or unauthorized" },
          { status: 404 }
        )
      }
    }

    const incident = await prisma.incident.create({
      data: validatedData,
      include: {
        client: true,
        caregiver: true,
        shift: true,
      },
    })

    return NextResponse.json(incident, { status: 201 })
  } catch (error: any) {
    console.error("Error creating incident:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
