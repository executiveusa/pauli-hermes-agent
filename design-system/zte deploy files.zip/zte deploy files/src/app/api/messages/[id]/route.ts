import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { updateMessageSchema } from "@/lib/validations"

// GET - Get message by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const message = await prisma.message.findUnique({
      where: { id: params.id },
      include: {
        sender: true,
        receiver: true,
      },
    })

    if (!message) {
      return NextResponse.json(
        { error: "Message not found" },
        { status: 404 }
      )
    }

    // Check authorization - user must be sender or receiver
    if (
      message.senderId !== user.id &&
      message.receiverId !== user.id
    ) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    return NextResponse.json(message, { status: 200 })
  } catch (error) {
    console.error("Error fetching message:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// PATCH - Update message (mark as read)
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingMessage = await prisma.message.findUnique({
      where: { id: params.id },
    })

    if (!existingMessage) {
      return NextResponse.json(
        { error: "Message not found" },
        { status: 404 }
      )
    }

    // Check authorization - user must be receiver to mark as read
    if (existingMessage.receiverId !== user.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    const body = await request.json()
    const validatedData = updateMessageSchema.parse(body)

    const updateData: any = { ...validatedData }
    if (validatedData.read === true && existingMessage.readAt === null) {
      updateData.readAt = new Date()
    }

    const message = await prisma.message.update({
      where: { id: params.id },
      data: updateData,
      include: {
        sender: true,
        receiver: true,
      },
    })

    return NextResponse.json(message, { status: 200 })
  } catch (error: any) {
    console.error("Error updating message:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// DELETE - Delete message
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const existingMessage = await prisma.message.findUnique({
      where: { id: params.id },
    })

    if (!existingMessage) {
      return NextResponse.json(
        { error: "Message not found" },
        { status: 404 }
      )
    }

    // Check authorization - user must be sender or receiver
    if (
      existingMessage.senderId !== user.id &&
      existingMessage.receiverId !== user.id
    ) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 403 }
      )
    }

    await prisma.message.delete({
      where: { id: params.id },
    })

    return NextResponse.json(
      { message: "Message deleted successfully" },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error deleting message:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
