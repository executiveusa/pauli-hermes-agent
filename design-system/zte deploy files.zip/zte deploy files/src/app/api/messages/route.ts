import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { createMessageSchema } from "@/lib/validations"

// GET - List messages with pagination and filtering
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    // Parse query parameters
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "20")
    const folder = searchParams.get("folder") || "inbox" // inbox, sent, unread
    const senderId = searchParams.get("senderId")
    const receiverId = searchParams.get("receiverId")

    const skip = (page - 1) * limit

    // Build filter based on folder
    let where: any = {
      organization: {
        id: user.organizationId,
      },
    }

    if (folder === "inbox") {
      where.receiverId = user.id
    } else if (folder === "sent") {
      where.senderId = user.id
    } else if (folder === "unread") {
      where.read = false
      where.receiverId = user.id
    }

    if (senderId) where.senderId = senderId
    if (receiverId) where.receiverId = receiverId

    const [messages, total] = await Promise.all([
      prisma.message.findMany({
        where,
        include: {
          sender: true,
          receiver: true,
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.message.count({ where }),
    ])

    return NextResponse.json(
      {
        data: messages,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error("Error fetching messages:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

// POST - Create message
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !session.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { organization: true },
    })

    if (!user?.organizationId) {
      return NextResponse.json(
        { error: "Organization not found" },
        { status: 400 }
      )
    }

    const body = await request.json()
    const validatedData = createMessageSchema.parse(body)

    // Verify receiver exists and belongs to same organization
    const receiver = await prisma.user.findUnique({
      where: { id: validatedData.receiverId },
    })

    if (!receiver || receiver.organizationId !== user.organizationId) {
      return NextResponse.json(
        { error: "Recipient not found or unauthorized" },
        { status: 404 }
      )
    }

    const message = await prisma.message.create({
      data: {
        content: validatedData.content,
        senderId: user.id,
        receiverId: validatedData.receiverId,
        organizationId: user.organizationId,
      },
      include: {
        sender: true,
        receiver: true,
      },
    })

    return NextResponse.json(message, { status: 201 })
  } catch (error: any) {
    console.error("Error creating message:", error)
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
