import type { Metadata, Viewport } from "next"
import { Inter, Playfair_Display } from "next/font/google"
import "./globals.css"
import { cn } from "@/lib/utils"
import { Providers } from "./providers"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--font-playfair" })

export const metadata: Metadata = {
  title: {
    default: "Golden Hearts Home Care | Premium In-Home Care Services",
    template: "%s | Golden Hearts Home Care",
  },
  description: "Luxury private caregiver placement for high-net-worth families in Scottsdale, Arizona. Exceptional care for your loved ones with dignity and compassion.",
  keywords: ["home care", "private caregiver", "luxury home care", "Scottsdale care", "senior care", "in-home care"],
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#111827" },
  ],
  viewportFit: "cover",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn("min-h-screen bg-background font-sans antialiased", inter.variable, playfair.variable)}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
