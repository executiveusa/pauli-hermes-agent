"use client"

import * as React from "react"
import { motion, useReducedMotion } from "framer-motion"
import { cn } from "@/lib/utils"

interface AnimatedTextProps {
  text: string
  className?: string
  delay?: number
  as?: "h1" | "h2" | "h3" | "h4" | "p" | "span"
  gradient?: boolean
}

export function AnimatedText({ 
  text, 
  className, 
  delay = 0,
  as: Component = "p",
  gradient = false
}: AnimatedTextProps) {
  const prefersReducedMotion = useReducedMotion()

  if (prefersReducedMotion) {
    return (
      <Component className={cn(gradient && "gradient-text-warm", className)}>
        {text}
      </Component>
    )
  }

  return (
    <motion.span
      className={cn("inline-block", gradient && "gradient-text-warm", className)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: "easeOut" }}
    >
      {text}
    </motion.span>
  )
}

interface SplitTextProps {
  text: string
  className?: string
  delay?: number
  staggerDelay?: number
  as?: "h1" | "h2" | "h3" | "h4" | "p" | "span"
}

export function SplitText({ 
  text, 
  className, 
  delay = 0,
  staggerDelay = 0.03,
  as: Component = "span"
}: SplitTextProps) {
  const prefersReducedMotion = useReducedMotion()
  const words = text.split(" ")

  if (prefersReducedMotion) {
    return <Component className={className}>{text}</Component>
  }

  return (
    <Component className={cn("inline-flex flex-wrap", className)}>
      {words.map((word, wordIndex) => (
        <span key={wordIndex} className="inline-block overflow-hidden mr-[0.25em]">
          <motion.span
            className="inline-block"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            transition={{
              duration: 0.5,
              delay: delay + wordIndex * staggerDelay,
              ease: [0.33, 1, 0.68, 1],
            }}
          >
            {word}
          </motion.span>
        </span>
      ))}
    </Component>
  )
}
