"use client"

import * as React from "react"
import { motion, useReducedMotion, useInView } from "framer-motion"
import { cn } from "@/lib/utils"

interface StatCardProps {
  value: string | number
  label: string
  suffix?: string
  prefix?: string
  className?: string
  delay?: number
}

export function StatCard({ 
  value, 
  label, 
  suffix,
  prefix,
  className,
  delay = 0
}: StatCardProps) {
  const ref = React.useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const prefersReducedMotion = useReducedMotion()

  const content = (
    <div 
      ref={ref}
      className={cn(
        "text-center p-6 rounded-2xl",
        "bg-white/70 dark:bg-gray-800/70 backdrop-blur-xl",
        "border border-white/20 dark:border-gray-700/30",
        "shadow-lg shadow-black/5",
        className
      )}
    >
      <div className="text-3xl md:text-4xl font-bold text-amber-600 dark:text-amber-400">
        {prefix}
        <span>{value}</span>
        {suffix}
      </div>
      <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">{label}</div>
    </div>
  )

  if (prefersReducedMotion) {
    return content
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
      transition={{ 
        duration: 0.5, 
        delay,
        ease: [0.33, 1, 0.68, 1]
      }}
    >
      {content}
    </motion.div>
  )
}
