"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface SectionProps extends React.HTMLAttributes<HTMLElement> {
  variant?: "default" | "muted" | "dark" | "cream"
  spacing?: "sm" | "md" | "lg" | "xl"
}

const variantClasses = {
  default: "bg-white dark:bg-gray-950",
  muted: "bg-gray-50 dark:bg-gray-900",
  dark: "bg-gray-900 dark:bg-gray-950",
  cream: "bg-[#F8F5F0] dark:bg-gray-900",
}

const spacingClasses = {
  sm: "py-12 md:py-16",
  md: "py-16 md:py-20",
  lg: "py-20 md:py-28",
  xl: "py-24 md:py-32",
}

export function Section({ 
  className, 
  variant = "default",
  spacing = "lg",
  children, 
  ...props 
}: SectionProps) {
  return (
    <section 
      className={cn(
        variantClasses[variant],
        spacingClasses[spacing],
        className
      )} 
      {...props}
    >
      {children}
    </section>
  )
}
