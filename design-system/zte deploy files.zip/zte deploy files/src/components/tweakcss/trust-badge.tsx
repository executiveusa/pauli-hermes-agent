"use client"

import * as React from "react"
import { motion, useReducedMotion } from "framer-motion"
import { cn } from "@/lib/utils"
import { Shield, Award, CheckCircle, Star } from "lucide-react"

interface TrustBadgeProps {
  icon?: "shield" | "award" | "check" | "star"
  title: string
  description?: string
  className?: string
}

const icons = {
  shield: Shield,
  award: Award,
  check: CheckCircle,
  star: Star,
}

export function TrustBadge({ 
  icon = "shield", 
  title, 
  description,
  className 
}: TrustBadgeProps) {
  const prefersReducedMotion = useReducedMotion()
  const Icon = icons[icon]

  const content = (
    <div 
      className={cn(
        "flex items-center gap-3 rounded-xl bg-white/80 dark:bg-gray-800/80",
        "border border-gray-200/50 dark:border-gray-700/50",
        "px-4 py-3 shadow-lg backdrop-blur-sm",
        "transition-all duration-200 hover:shadow-xl cursor-default",
        className
      )}
    >
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="text-sm font-semibold text-gray-900 dark:text-white">{title}</div>
        {description && (
          <div className="text-xs text-gray-500 dark:text-gray-400">{description}</div>
        )}
      </div>
    </div>
  )

  if (prefersReducedMotion) {
    return content
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
    >
      {content}
    </motion.div>
  )
}
