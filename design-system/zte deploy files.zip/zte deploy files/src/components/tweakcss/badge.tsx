"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "gold" | "trust" | "success" | "outline"
}

const variantClasses = {
  default: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  gold: "bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border border-amber-200/50 dark:border-amber-700/30",
  trust: "bg-sky-50 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400 border border-sky-200/50 dark:border-sky-700/30",
  success: "bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-700/30",
  outline: "bg-transparent border border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300",
}

export function Badge({ 
  className, 
  variant = "default", 
  children, 
  ...props 
}: BadgeProps) {
  return (
    <span 
      className={cn(
        "inline-flex items-center rounded-full px-4 py-1.5 text-sm font-medium",
        "transition-colors duration-200",
        variantClasses[variant],
        className
      )} 
      {...props}
    >
      {children}
    </span>
  )
}
