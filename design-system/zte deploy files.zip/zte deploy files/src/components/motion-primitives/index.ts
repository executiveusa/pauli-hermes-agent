// Motion Primitives - Animation & Interaction Components
// These components provide sophisticated animations following UI/UX Pro Max protocol

export { FadeIn, FadeInStagger } from "./fade-in"
export { MagneticButton } from "./magnetic-button"
export { ParallaxImage } from "./parallax-image"
export { ScrollReveal } from "./scroll-reveal"
export { FloatingElement } from "./floating-element"
export { TextReveal } from "./text-reveal"
