"use client"

import * as React from "react"
import { motion, useMotionValue, useSpring, useReducedMotion } from "framer-motion"
import { cn } from "@/lib/utils"

interface MagneticButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'onAnimationStart' | 'onDrag' | 'onDragEnd' | 'onDragStart'> {
  children: React.ReactNode
  variant?: "primary" | "secondary" | "outline"
  size?: "sm" | "md" | "lg" | "xl"
  magnetStrength?: number
}

const variantClasses = {
  primary: "bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg shadow-amber-500/25 hover:shadow-xl hover:shadow-amber-500/30",
  secondary: "bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 shadow-md hover:shadow-lg",
  outline: "bg-transparent border-2 border-amber-500 text-amber-600 dark:text-amber-400 hover:bg-amber-500/10",
}

const sizeClasses = {
  sm: "h-10 px-4 text-sm rounded-lg",
  md: "h-12 px-6 text-sm rounded-xl",
  lg: "h-14 px-8 text-base rounded-xl",
  xl: "h-16 px-10 text-lg rounded-2xl",
}

export function MagneticButton({
  children,
  className,
  variant = "primary",
  size = "md",
  magnetStrength = 0.3,
  ...props
}: MagneticButtonProps) {
  const prefersReducedMotion = useReducedMotion()
  const ref = React.useRef<HTMLButtonElement>(null)

  const x = useMotionValue(0)
  const y = useMotionValue(0)

  const springConfig = { stiffness: 150, damping: 15 }
  const springX = useSpring(x, springConfig)
  const springY = useSpring(y, springConfig)

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (prefersReducedMotion || !ref.current) return

    const rect = ref.current.getBoundingClientRect()
    const centerX = rect.left + rect.width / 2
    const centerY = rect.top + rect.height / 2

    const deltaX = (e.clientX - centerX) * magnetStrength
    const deltaY = (e.clientY - centerY) * magnetStrength

    x.set(deltaX)
    y.set(deltaY)
  }

  const handleMouseLeave = () => {
    x.set(0)
    y.set(0)
  }

  return (
    <motion.button
      ref={ref}
      className={cn(
        "relative inline-flex items-center justify-center font-semibold",
        "cursor-pointer transition-colors duration-200",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        "tap-target", // Ensure 44px minimum touch target
        variantClasses[variant],
        sizeClasses[size],
        className
      )}
      style={{ x: springX, y: springY }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{ scale: prefersReducedMotion ? 1 : 1.02 }}
      whileTap={{ scale: prefersReducedMotion ? 1 : 0.98 }}
      {...props}
    >
      {children}
    </motion.button>
  )
}
