"use client"

import * as React from "react"
import { motion, useScroll, useTransform, useReducedMotion } from "framer-motion"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface ParallaxImageProps {
  src: string
  alt: string
  className?: string
  containerClassName?: string
  speed?: number
  priority?: boolean
}

export function ParallaxImage({
  src,
  alt,
  className,
  containerClassName,
  speed = 0.5,
  priority = false,
}: ParallaxImageProps) {
  const prefersReducedMotion = useReducedMotion()
  const ref = React.useRef<HTMLDivElement>(null)

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], ["0%", `${speed * 100}%`])

  if (prefersReducedMotion) {
    return (
      <div ref={ref} className={cn("relative overflow-hidden", containerClassName)}>
        <Image
          src={src}
          alt={alt}
          fill
          className={cn("object-cover", className)}
          priority={priority}
        />
      </div>
    )
  }

  return (
    <div ref={ref} className={cn("relative overflow-hidden", containerClassName)}>
      <motion.div className="absolute inset-0" style={{ y }}>
        <Image
          src={src}
          alt={alt}
          fill
          className={cn("object-cover scale-110", className)}
          priority={priority}
        />
      </motion.div>
    </div>
  )
}
