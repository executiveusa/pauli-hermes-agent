"use client"

import * as React from "react"
import Link from "next/link"
import { motion, useScroll, useMotionValueEvent } from "framer-motion"
import { cn } from "@/lib/utils"
import { Button } from "./button"

export function Navigation({ className }: { className?: string }) {
  const [isScrolled, setIsScrolled] = React.useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false)
  const { scrollY } = useScroll()

  useMotionValueEvent(scrollY, "change", (latest) => {
    setIsScrolled(latest > 50)
  })

  const navLinks = [
    { label: "Services", href: "#services" },
    { label: "How It Works", href: "#how-it-works" },
    { label: "Caregivers", href: "#caregivers" },
    { label: "Pricing", href: "#pricing" },
    { label: "Contact", href: "#contact" },
  ]

  return (
    <>
      <motion.header
        className={cn(
          "fixed left-0 right-0 top-0 z-50 transition-all duration-300",
          isScrolled ? "bg-white/80 shadow-lg backdrop-blur-xl dark:bg-gray-900/80" : "bg-transparent",
          className
        )}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link href="/" className="flex items-center gap-3">
            <motion.div
              className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 shadow-lg shadow-gold-500/30"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <svg className="h-7 w-7 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
              </svg>
            </motion.div>
            <div className="flex flex-col">
              <span className={cn("text-lg font-bold transition-colors", isScrolled ? "text-gray-900 dark:text-white" : "text-white")}>
                Golden Hearts
              </span>
              <span className={cn("text-xs transition-colors", isScrolled ? "text-gray-600 dark:text-gray-400" : "text-white/70")}>
                Home Care
              </span>
            </div>
          </Link>

          <div className="hidden items-center gap-8 md:flex">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn("text-sm font-medium transition-colors hover:text-gold-500", isScrolled ? "text-gray-700 dark:text-gray-300" : "text-white/90")}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div className="hidden items-center gap-4 md:flex">
            <Link href="/login">
              <Button variant={isScrolled ? "ghost" : "glass"} className={cn(!isScrolled && "text-white hover:text-white")}>
                Sign In
              </Button>
            </Link>
            <Link href="/register">
              <Button variant="premium">Get Started</Button>
            </Link>
          </div>

          <button
            className="flex h-10 w-10 items-center justify-center rounded-lg md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <motion.div animate={isMobileMenuOpen ? "open" : "closed"} className="relative h-5 w-6">
              <motion.span
                className={cn("absolute left-0 h-0.5 w-6 rounded-full", isScrolled ? "bg-gray-900 dark:bg-white" : "bg-white")}
                style={{ top: "0%" }}
                variants={{ closed: { rotate: 0, y: 0 }, open: { rotate: 45, y: 10 } }}
              />
              <motion.span
                className={cn("absolute left-0 top-1/2 h-0.5 w-6 -translate-y-1/2 rounded-full", isScrolled ? "bg-gray-900 dark:bg-white" : "bg-white")}
                variants={{ closed: { opacity: 1 }, open: { opacity: 0 } }}
              />
              <motion.span
                className={cn("absolute left-0 h-0.5 w-6 rounded-full", isScrolled ? "bg-gray-900 dark:bg-white" : "bg-white")}
                style={{ bottom: "0%" }}
                variants={{ closed: { rotate: 0, y: 0 }, open: { rotate: -45, y: -10 } }}
              />
            </motion.div>
          </button>
        </nav>
      </motion.header>

      <motion.div
        className={cn("fixed inset-0 z-40 bg-gray-900/50 backdrop-blur-sm md:hidden", isMobileMenuOpen ? "pointer-events-auto" : "pointer-events-none")}
        initial={false}
        animate={{ opacity: isMobileMenuOpen ? 1 : 0 }}
        onClick={() => setIsMobileMenuOpen(false)}
      />

      <motion.div
        className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl bg-white p-6 shadow-2xl dark:bg-gray-900 md:hidden"
        initial={{ y: "100%" }}
        animate={{ y: isMobileMenuOpen ? 0 : "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        <div className="mb-6 flex flex-col gap-4">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} className="text-lg font-medium text-gray-900 dark:text-white" onClick={() => setIsMobileMenuOpen(false)}>
              {link.label}
            </Link>
          ))}
        </div>
        <div className="flex flex-col gap-3">
          <Link href="/login" onClick={() => setIsMobileMenuOpen(false)}>
            <Button variant="outline" className="w-full">Sign In</Button>
          </Link>
          <Link href="/register" onClick={() => setIsMobileMenuOpen(false)}>
            <Button variant="premium" className="w-full">Get Started</Button>
          </Link>
        </div>
      </motion.div>
    </>
  )
}

export default Navigation
