import nodemailer from "nodemailer"

interface EmailOptions {
  to: string
  subject: string
  html: string
  text?: string
}

// Initialize email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_SECURE === "true", // true for 465, false for other ports
  auth:
    process.env.SMTP_USER && process.env.SMTP_PASSWORD
      ? {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASSWORD,
        }
      : undefined,
})

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  try {
    if (!process.env.SMTP_HOST || !process.env.SMTP_USER) {
      console.warn("Email service not configured. Email not sent.")
      return false
    }

    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: options.to,
      subject: options.subject,
      html: options.html,
      text: options.text,
    })

    console.log("Email sent:", info.messageId)
    return true
  } catch (error) {
    console.error("Error sending email:", error)
    return false
  }
}

export async function sendInvoiceEmail(
  email: string,
  clientName: string,
  invoiceNumber: string,
  amount: number
): Promise<boolean> {
  const html = `
    <h1>Invoice Notification</h1>
    <p>Dear ${clientName},</p>
    <p>Your invoice <strong>${invoiceNumber}</strong> is ready for payment.</p>
    <p><strong>Amount Due:</strong> $${(amount / 100).toFixed(2)}</p>
    <p>Please log in to your account to view the full invoice and payment options.</p>
    <p>Thank you for choosing Golden Hearts Home Care.</p>
  `

  return sendEmail({
    to: email,
    subject: `Invoice ${invoiceNumber} - Golden Hearts Home Care`,
    html,
    text: `Invoice ${invoiceNumber}: $${(amount / 100).toFixed(2)}`,
  })
}

export async function sendPaymentConfirmationEmail(
  email: string,
  clientName: string,
  invoiceNumber: string,
  amount: number
): Promise<boolean> {
  const html = `
    <h1>Payment Confirmation</h1>
    <p>Dear ${clientName},</p>
    <p>Your payment for invoice <strong>${invoiceNumber}</strong> has been received and processed.</p>
    <p><strong>Amount Paid:</strong> $${(amount / 100).toFixed(2)}</p>
    <p>Thank you for your prompt payment.</p>
    <p>Golden Hearts Home Care</p>
  `

  return sendEmail({
    to: email,
    subject: `Payment Confirmation - Invoice ${invoiceNumber}`,
    html,
    text: `Payment received for invoice ${invoiceNumber}: $${(amount / 100).toFixed(2)}`,
  })
}

export async function sendPasswordResetEmail(
  email: string,
  resetLink: string
): Promise<boolean> {
  const html = `
    <h1>Password Reset Request</h1>
    <p>You requested to reset your password for your Golden Hearts Home Care account.</p>
    <p><a href="${resetLink}" style="background-color: #f5c518; color: #000; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Reset Password</a></p>
    <p>If you didn't request this, please ignore this email.</p>
    <p>This link will expire in 24 hours.</p>
  `

  return sendEmail({
    to: email,
    subject: "Password Reset - Golden Hearts Home Care",
    html,
    text: `Reset your password: ${resetLink}`,
  })
}

export async function sendWelcomeEmail(
  email: string,
  name: string
): Promise<boolean> {
  const html = `
    <h1>Welcome to Golden Hearts Home Care</h1>
    <p>Dear ${name},</p>
    <p>Thank you for creating your account. We're excited to have you on board!</p>
    <p>You can now log in to your dashboard to manage your care services.</p>
    <p><a href="${process.env.NEXTAUTH_URL}/login" style="background-color: #f5c518; color: #000; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Log In Now</a></p>
    <p>If you have any questions, please don't hesitate to contact us.</p>
    <p>Golden Hearts Home Care Team</p>
  `

  return sendEmail({
    to: email,
    subject: "Welcome to Golden Hearts Home Care",
    html,
    text: "Welcome! Log in to your account.",
  })
}

export async function sendIncidentAlertEmail(
  email: string,
  clientName: string,
  incidentTitle: string,
  severity: string
): Promise<boolean> {
  const html = `
    <h1>Incident Alert</h1>
    <p>An incident has been reported for <strong>${clientName}</strong>.</p>
    <p><strong>Title:</strong> ${incidentTitle}</p>
    <p><strong>Severity:</strong> <span style="color: ${
      severity === "CRITICAL"
        ? "red"
        : severity === "HIGH"
          ? "orange"
          : "yellow"
    };">${severity}</span></p>
    <p>Please log in to review the incident details.</p>
    <p>Golden Hearts Home Care</p>
  `

  return sendEmail({
    to: email,
    subject: `Incident Alert: ${incidentTitle}`,
    html,
    text: `Incident reported for ${clientName}: ${incidentTitle} (${severity})`,
  })
}
