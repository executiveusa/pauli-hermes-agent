export const config = {
  app: {
    name: "Golden Hearts Home Care",
    tagline: "Premium In-Home Care for Those You Love",
    description: "Luxury private caregiver placement for high-net-worth families in Scottsdale, Arizona",
    url: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
    version: "1.0.0",
  },
  features: {
    mockMode: process.env.NEXT_PUBLIC_MOCK_MODE === "true",
    enableBitcoin: process.env.NEXT_PUBLIC_ENABLE_BITCOIN === "true",
    enableAI: process.env.NEXT_PUBLIC_ENABLE_AI === "true",
  },
  business: {
    defaultLocation: { lat: 33.4942, lng: -111.9261 },
    serviceRadius: 30,
    minShiftHours: 4,
    maxShiftHours: 24,
    hourlyRate: { min: 35, max: 75 },
    platformFee: 15,
  },
} as const

export function isMockMode(): boolean {
  return config.features.mockMode
}

export default config
