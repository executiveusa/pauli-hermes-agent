enum LogLevel {
  DEBUG = "DEBUG",
  INFO = "INFO",
  WARN = "WARN",
  ERROR = "ERROR",
}

interface LogContext {
  userId?: string
  organizationId?: string
  requestId?: string
  [key: string]: any
}

class Logger {
  private isDev = process.env.NODE_ENV === "development"

  private formatMessage(
    level: LogLevel,
    message: string,
    context?: LogContext
  ): string {
    const timestamp = new Date().toISOString()
    const contextStr = context ? JSON.stringify(context) : ""
    return `[${timestamp}] [${level}] ${message} ${contextStr}`
  }

  debug(message: string, context?: LogContext) {
    if (this.isDev) {
      console.debug(this.formatMessage(LogLevel.DEBUG, message, context))
    }
  }

  info(message: string, context?: LogContext) {
    console.log(this.formatMessage(LogLevel.INFO, message, context))
  }

  warn(message: string, context?: LogContext) {
    console.warn(this.formatMessage(LogLevel.WARN, message, context))
  }

  error(message: string, error?: Error, context?: LogContext) {
    console.error(this.formatMessage(LogLevel.ERROR, message, context), error)

    // TODO: Send to Sentry or external logging service
    // Sentry.captureException(error, { extra: context })
  }

  apiRequest(method: string, path: string, statusCode: number, duration: number) {
    this.info(`API Request`, {
      method,
      path,
      statusCode,
      durationMs: duration,
    })
  }

  apiError(method: string, path: string, statusCode: number, error: string) {
    this.error(`API Error`, new Error(error), {
      method,
      path,
      statusCode,
    })
  }

  databaseQuery(query: string, duration: number) {
    if (this.isDev) {
      this.debug(`Database Query`, {
        query,
        durationMs: duration,
      })
    }
  }

  databaseError(error: Error, query: string) {
    this.error(`Database Error`, error, {
      query,
    })
  }

  authEvent(event: "login" | "logout" | "register", userId: string, success: boolean) {
    this.info(`Auth Event`, {
      event,
      userId,
      success,
    })
  }
}

export const logger = new Logger()
