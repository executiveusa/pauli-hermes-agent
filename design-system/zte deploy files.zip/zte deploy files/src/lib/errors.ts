export class APIError extends Error {
  constructor(
    public statusCode: number,
    message: string,
    public code?: string
  ) {
    super(message)
    this.name = "APIError"
  }
}

export class ValidationError extends APIError {
  constructor(message: string, public errors?: Record<string, string[]>) {
    super(400, message, "VALIDATION_ERROR")
    this.name = "ValidationError"
  }
}

export class UnauthorizedError extends APIError {
  constructor(message = "Unauthorized") {
    super(401, message, "UNAUTHORIZED")
    this.name = "UnauthorizedError"
  }
}

export class ForbiddenError extends APIError {
  constructor(message = "Forbidden") {
    super(403, message, "FORBIDDEN")
    this.name = "ForbiddenError"
  }
}

export class NotFoundError extends APIError {
  constructor(resource: string) {
    super(404, `${resource} not found`, "NOT_FOUND")
    this.name = "NotFoundError"
  }
}

export class ConflictError extends APIError {
  constructor(message: string) {
    super(409, message, "CONFLICT")
    this.name = "ConflictError"
  }
}

export class RateLimitError extends APIError {
  constructor(public retryAfter: number) {
    super(429, "Too many requests", "RATE_LIMITED")
    this.name = "RateLimitError"
  }
}

export class InternalServerError extends APIError {
  constructor(message = "Internal server error") {
    super(500, message, "INTERNAL_SERVER_ERROR")
    this.name = "InternalServerError"
  }
}

export function getErrorResponse(error: unknown) {
  if (error instanceof APIError) {
    return {
      statusCode: error.statusCode,
      body: {
        error: error.message,
        code: error.code,
        ...(error instanceof ValidationError && { errors: error.errors }),
        ...(error instanceof RateLimitError && { retryAfter: error.retryAfter }),
      },
    }
  }

  if (error instanceof Error) {
    // Check for Zod validation errors
    if (error.name === "ZodError") {
      const zodError = error as any
      const errors: Record<string, string[]> = {}
      for (const issue of zodError.errors) {
        const path = issue.path.join(".")
        if (!errors[path]) {
          errors[path] = []
        }
        errors[path].push(issue.message)
      }
      return {
        statusCode: 400,
        body: {
          error: "Validation error",
          code: "VALIDATION_ERROR",
          errors,
        },
      }
    }

    // Check for Prisma errors
    if (error.name === "PrismaClientKnownRequestError") {
      const prismaError = error as any
      if (prismaError.code === "P2025") {
        return {
          statusCode: 404,
          body: {
            error: "Resource not found",
            code: "NOT_FOUND",
          },
        }
      }
      if (prismaError.code === "P2002") {
        return {
          statusCode: 409,
          body: {
            error: "Unique constraint violation",
            code: "CONFLICT",
            field: prismaError.meta?.target?.[0],
          },
        }
      }
    }

    console.error("Unhandled error:", error)
    return {
      statusCode: 500,
      body: {
        error: "Internal server error",
        code: "INTERNAL_SERVER_ERROR",
      },
    }
  }

  return {
    statusCode: 500,
    body: {
      error: "Internal server error",
      code: "INTERNAL_SERVER_ERROR",
    },
  }
}
