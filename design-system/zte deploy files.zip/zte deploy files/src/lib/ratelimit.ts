// Simple in-memory rate limiter
// For production, use Redis or similar
interface RateLimitEntry {
  count: number
  resetTime: number
}

const rateLimitStore = new Map<string, RateLimitEntry>()

// Configuration for different endpoints
const RATE_LIMITS = {
  api: { requests: 100, windowMs: 60 * 1000 }, // 100 requests per minute
  auth: { requests: 5, windowMs: 15 * 60 * 1000 }, // 5 requests per 15 minutes
  payment: { requests: 10, windowMs: 60 * 1000 }, // 10 requests per minute
  default: { requests: 30, windowMs: 60 * 1000 }, // 30 requests per minute
}

type RateLimitCategory = keyof typeof RATE_LIMITS

export function checkRateLimit(
  identifier: string,
  category: RateLimitCategory = "default"
): { allowed: boolean; remainingRequests: number; resetTime: number } {
  const config = RATE_LIMITS[category]
  const now = Date.now()
  const key = `${identifier}:${category}`

  let entry = rateLimitStore.get(key)

  if (!entry || now > entry.resetTime) {
    // Create new rate limit window
    entry = {
      count: 1,
      resetTime: now + config.windowMs,
    }
    rateLimitStore.set(key, entry)
    return {
      allowed: true,
      remainingRequests: config.requests - 1,
      resetTime: entry.resetTime,
    }
  }

  entry.count++

  if (entry.count > config.requests) {
    return {
      allowed: false,
      remainingRequests: 0,
      resetTime: entry.resetTime,
    }
  }

  return {
    allowed: true,
    remainingRequests: config.requests - entry.count,
    resetTime: entry.resetTime,
  }
}

export function getClientIp(headers: Headers): string {
  const forwarded = headers.get("x-forwarded-for")
  if (forwarded) {
    return forwarded.split(",")[0].trim()
  }
  return headers.get("x-real-ip") || "unknown"
}

// Cleanup old entries periodically
setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of rateLimitStore.entries()) {
    if (now > entry.resetTime) {
      rateLimitStore.delete(key)
    }
  }
}, 60 * 1000) // Cleanup every minute
