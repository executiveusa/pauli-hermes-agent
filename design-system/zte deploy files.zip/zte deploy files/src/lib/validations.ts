import { z } from "zod"

// ============================================
// PAGINATION
// ============================================

export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
  search: z.string().optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
})

export type PaginationQuery = z.infer<typeof paginationSchema>

// ============================================
// CLIENT
// ============================================

export const createClientSchema = z.object({
  firstName: z.string().min(1, "First name required"),
  lastName: z.string().min(1, "Last name required"),
  dateOfBirth: z.string().datetime().optional(),
  gender: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  address: z.string().min(1, "Address required"),
  city: z.string().min(1, "City required"),
  state: z.string().min(1, "State required"),
  zip: z.string().min(1, "ZIP required"),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  medicalConditions: z.string().optional(),
  medications: z.string().optional(),
  allergies: z.string().optional(),
  emergencyContact: z.string().optional(),
  emergencyPhone: z.string().optional(),
  careLevel: z.enum(["COMPANION", "PERSONAL", "SKILLED", "MEMORY", "HOSPICE"]).default("COMPANION"),
  preferredGender: z.string().optional(),
  languages: z.array(z.string()).default([]),
  notes: z.string().optional(),
  hourlyRate: z.number().int().default(4500),
  billingType: z.enum(["PRIVATE", "INSURANCE", "MEDICAID", "ALTCS", "VETERANS"]).default("PRIVATE"),
  insuranceProvider: z.string().optional(),
  insuranceId: z.string().optional(),
  status: z.enum(["ACTIVE", "INACTIVE", "PENDING", "DISCHARGED"]).default("ACTIVE"),
})

export const updateClientSchema = createClientSchema.partial()

// ============================================
// CAREGIVER
// ============================================

export const createCaregiverSchema = z.object({
  firstName: z.string().min(1, "First name required"),
  lastName: z.string().min(1, "Last name required"),
  phone: z.string().min(1, "Phone required"),
  email: z.string().email("Valid email required"),
  dateOfBirth: z.string().datetime().optional(),
  gender: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  certifications: z.array(z.string()).default([]),
  specialties: z.array(z.string()).default([]),
  languages: z.array(z.string()).default([]),
  yearsExperience: z.number().int().default(0),
  bio: z.string().optional(),
  hourlyRate: z.number().int().default(2500),
  employmentType: z.enum(["W2", "CONTRACT_1099"]).default("W2"),
  taxId: z.string().optional(),
  backgroundCheck: z.boolean().default(false),
  backgroundCheckDate: z.string().datetime().optional(),
  drugTest: z.boolean().default(false),
  drugTestDate: z.string().datetime().optional(),
  cprCertified: z.boolean().default(false),
  cprExpiration: z.string().datetime().optional(),
  tbTest: z.boolean().default(false),
  tbTestDate: z.string().datetime().optional(),
  status: z.enum(["ACTIVE", "INACTIVE", "PENDING", "SUSPENDED", "TERMINATED"]).default("PENDING"),
  rating: z.number().min(0).max(5).default(5.0),
  totalShifts: z.number().int().default(0),
})

export const updateCaregiverSchema = createCaregiverSchema.partial()

// ============================================
// SHIFT
// ============================================

export const createShiftSchema = z.object({
  scheduledStart: z.string().datetime("Invalid date format"),
  scheduledEnd: z.string().datetime("Invalid date format"),
  clientId: z.string().min(1, "Client required"),
  caregiverId: z.string().min(1, "Caregiver required"),
  status: z.enum(["SCHEDULED", "CONFIRMED", "IN_PROGRESS", "COMPLETED", "CANCELLED", "NO_SHOW"]).default("SCHEDULED"),
  notes: z.string().optional(),
  tasks: z.array(z.string()).default([]),
  hourlyRate: z.number().int().min(0),
  caregiverRate: z.number().int().min(0),
})

export const updateShiftSchema = createShiftSchema.partial()

export const clockInSchema = z.object({
  latitude: z.number(),
  longitude: z.number(),
})

export const clockOutSchema = z.object({
  latitude: z.number(),
  longitude: z.number(),
})

// ============================================
// CARE NOTE
// ============================================

export const createCareNoteSchema = z.object({
  content: z.string().min(1, "Content required"),
  category: z.enum(["GENERAL", "MEDICATION", "MEAL", "ACTIVITY", "HYGIENE", "HEALTH", "BEHAVIORAL"]).default("GENERAL"),
  mood: z.string().optional(),
  vitals: z.record(z.any()).optional(),
  shiftId: z.string().min(1, "Shift required"),
  clientId: z.string().min(1, "Client required"),
  caregiverId: z.string().min(1, "Caregiver required"),
})

export const updateCareNoteSchema = createCareNoteSchema.partial()

// ============================================
// INCIDENT
// ============================================

export const createIncidentSchema = z.object({
  title: z.string().min(1, "Title required"),
  description: z.string().min(1, "Description required"),
  severity: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).default("LOW"),
  actionTaken: z.string().optional(),
  followUpRequired: z.boolean().default(false),
  resolved: z.boolean().default(false),
  shiftId: z.string().optional(),
  clientId: z.string().min(1, "Client required"),
  caregiverId: z.string().min(1, "Caregiver required"),
})

export const updateIncidentSchema = createIncidentSchema.partial()

// ============================================
// INVOICE
// ============================================

export const createInvoiceSchema = z.object({
  clientId: z.string().min(1, "Client required"),
  periodStart: z.string().datetime("Invalid date format"),
  periodEnd: z.string().datetime("Invalid date format"),
  dueDate: z.string().datetime("Invalid date format"),
  subtotal: z.number().int().min(0),
  tax: z.number().int().default(0),
  discount: z.number().int().default(0),
  total: z.number().int().min(0),
  status: z.enum(["DRAFT", "SENT", "VIEWED", "PAID", "PARTIAL", "OVERDUE", "CANCELLED"]).default("DRAFT"),
  notes: z.string().optional(),
})

export const updateInvoiceSchema = createInvoiceSchema.partial()

// ============================================
// PAYMENT
// ============================================

export const createPaymentSchema = z.object({
  invoiceId: z.string().min(1, "Invoice required"),
  amount: z.number().int().min(1, "Amount must be positive"),
  method: z.enum(["CREDIT_CARD", "BANK_TRANSFER", "CHECK", "CASH", "BITCOIN", "ALTCS", "INSURANCE"]).default("CREDIT_CARD"),
})

export const updatePaymentSchema = z.object({
  status: z.enum(["PENDING", "PROCESSING", "COMPLETED", "FAILED", "REFUNDED"]).optional(),
  notes: z.string().optional(),
})

// ============================================
// PAYOUT
// ============================================

export const createPayoutSchema = z.object({
  caregiverId: z.string().min(1, "Caregiver required"),
  amount: z.number().int().min(0),
  periodStart: z.string().datetime("Invalid date format"),
  periodEnd: z.string().datetime("Invalid date format"),
  hoursWorked: z.number().min(0),
  status: z.enum(["PENDING", "APPROVED", "PROCESSING", "PAID", "FAILED"]).default("PENDING"),
  notes: z.string().optional(),
})

export const updatePayoutSchema = createPayoutSchema.partial()

// ============================================
// MESSAGE
// ============================================

export const createMessageSchema = z.object({
  content: z.string().min(1, "Message required"),
  receiverId: z.string().min(1, "Recipient required"),
})

export const updateMessageSchema = z.object({
  read: z.boolean().optional(),
})
