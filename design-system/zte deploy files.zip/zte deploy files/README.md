# ZTE Auto-Deploy — Quick Start

## 5 minutes to full autonomy on any repo

### Step 1 — Copy the workflow
```bash
mkdir -p .github/workflows
cp zte-autodeploy.yml .github/workflows/zte-autodeploy.yml
```

### Step 2 — Set your project ID (the ONLY line you touch)
```yaml
# In .github/workflows/zte-autodeploy.yml, line ~34:
VERCEL_PROJECT_ID: "prj_YOUR_PROJECT_ID_HERE"
```

### Step 3 — Add GitHub Secrets (one time per repo or org)
Go to: Settings → Secrets and variables → Actions → New repository secret

| Secret | Value |
|--------|-------|
| `VERCEL_TOKEN` | From vercel.com/account/tokens |
| `GH_PAT` | GitHub Personal Access Token (scopes: `repo`, `workflow`) |

### Step 4 — Push any branch
```bash
git push origin feature/my-feature
```

The pipeline does the rest:
- Installs Emerald Tablets if missing
- Scans for stubs, implements them via Ralphy
- Runs E2E tests
- Audits against the Emerald Tablets (dominant law)
- Deploys to Vercel
- Auto-merges to main when everything is green
- Notifies you

---

## Finding Your Vercel Project ID

```bash
# Via Vercel CLI
vercel projects ls

# Via dashboard
# vercel.com → Project → Settings → General → Project ID
```

## Emerald Tablets — The Dominant Law

The pipeline automatically installs the Emerald Tablets at `/emerald-tablets/` in your repo
on first run. These are:

- `taste-skill` — design law enforcement (UI/UX audit)
- `pauli-Uncodixfy` — ARCHON-X protocol scanner
- `paulsuperpowers` — superpower registry

**No deploy proceeds past Stage 3 unless the Emerald Tablets audit passes.**
This is the dominant law. It cannot be bypassed.

---

## Circuit Breakers

| Breaker | Condition |
|---------|-----------|
| Cost > $10 | Hard halt |
| Secret in file | Halt + alert |
| Emerald violation | Block merge |
| 3× same error | Escalate to Bambu |

---

*ZTE Auto-Deploy v1.0 | The Pauli Effect Ecosystem*
