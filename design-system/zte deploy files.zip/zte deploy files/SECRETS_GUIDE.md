# Golden Hearts Secret Management Guide

## Required Secrets for Production Deployment

### 1. DATABASE_URL (CRITICAL)
PostgreSQL connection string for Prisma ORM.
```
postgresql://username:password@host:port/database_name
```

### 2. NEXTAUTH_SECRET (CRITICAL)
Session encryption key. Generate with:
```bash
openssl rand -hex 32
```

### 3. NEXTAUTH_URL (CRITICAL)
Your production domain:
```
https://goldenhearts-beta.vercel.app
```

## Optional Secrets

### Google OAuth (if using social login)
- NEXTAUTH_GOOGLE_ID
- NEXTAUTH_GOOGLE_SECRET

### Email Service (if sending notifications)
- SMTP_HOST
- SMTP_PORT
- SMTP_USER
- SMTP_PASSWORD

## Vercel Deployment Setup

1. Go to Vercel Project Settings → Environment Variables
2. Add all required secrets
3. Redeploy application

## Security Best Practices

✓ Never commit .env.local to git
✓ Use strong, randomly generated secrets
✓ Rotate NEXTAUTH_SECRET periodically
✓ Use environment-specific secrets for dev/prod
✓ Monitor for exposed secrets in git history

## What the App Uses

Currently the Golden Hearts app only requires:
- DATABASE_URL (Prisma database connection)
- NEXTAUTH_SECRET (session encryption)
- NEXTAUTH_URL (OAuth callback URL)

All other secrets are OPTIONAL and only needed if you add additional features like:
- Google OAuth login
- Email notifications
- Payment processing
- Analytics services
