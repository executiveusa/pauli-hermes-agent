# Golden Hearts Build & Deployment Workflow

## How It Works

### 1. **Git Push Trigger**
```bash
git push origin main
```
- Commits pushed to GitHub's main branch automatically trigger Vercel webhook
- Vercel receives notification within seconds

### 2. **Vercel Build Pipeline**
```
[GitHub Webhook] → [Vercel Build] → [Prisma Generate] → [Next.js Build] → [Deploy]
```

**Steps:**
1. **Clone Repository** - Pulls latest code from GitHub
2. **Install Dependencies** - `npm install` (uses cache when available)
3. **Prisma Generate** - Generates TypeScript types from schema
4. **Next.js Build** - Compiles React, optimizes images, minifies code
5. **Deploy** - Pushes compiled app to CDN edges globally

### 3. **GitHub Actions (Optional CI/CD)**
Your `zte-autodeploy.yml` runs additional checks:
- Memory scanning
- Design audits
- E2E tests
- Lighthouse performance

### 4. **Live Deployment**
```
App deployed to Vercel global CDN
Available at: https://goldenhearts-beta.vercel.app
```

---

## Monitor Build in Real-Time

### **Method 1: Vercel Dashboard (Easiest)**
Go to: https://vercel.com/dashboard
- Click: executiveusa/goldenhearts
- View live build status, logs, and deployments
- Watch: CPU/memory usage, build progress

### **Method 2: Vercel CLI (Command Line)**
```powershell
# Install Vercel CLI (one-time)
npm install -g vercel

# Login to Vercel
vercel login

# Monitor current deployment
vercel list

# Watch logs in real-time
vercel logs goldenhearts --follow

# Deploy manually (optional - usually automatic)
vercel deploy --prod
```

### **Method 3: GitHub Actions Logs**
Go to: https://github.com/executiveusa/goldenhearts/actions
- Click latest workflow run
- View detailed CI/CD pipeline output

---

## Current Deployment Status

**Last Build**: March 26, 2026 11:36-11:37 UTC
- Commit: fe9d9a9
- Region: Washington D.C. (iad1)
- Status: Running Prisma generate
- Estimated completion: 2-3 minutes

---

## Vercel Build Cache & Performance

### Cache Layers
```
1. Build cache (node_modules, .next) - speeds up rebuilds
2. Image optimization cache - serves images at edge
3. CDN cache - global content distribution
```

### Typical Build Times
- **First build**: 2-3 minutes (fresh dependencies)
- **Incremental build**: 30-60 seconds (cached deps)
- **Deploy time**: 10-30 seconds (push to CDN)

---

## What Happens During the Build

```
11:36:58 Restored build cache (8ZJvTLDbfEAcQp2t69L97zbTPtbY)
11:37:06 > npx prisma generate
         → Compiles database schema to TypeScript types
11:37:08 > next build
         → Bundles React components
         → Optimizes images
         → Generates static pages
11:37:35 Deployment complete
11:37:40 Live at: https://goldenhearts-beta.vercel.app
```

---

## Common Build Issues & Fixes

| Issue | Cause | Fix |
|-------|-------|-----|
| "Could not resolve @prisma/client" | Missing deps | `npm install` then redeploy |
| Build timeout | Large dependencies | Increase timeout in vercel.json |
| Out of memory | Node.js limit exceeded | Vercel auto-scales, usually resolves |
| Stale cache | Old dependencies | Redeploy without cache: `vercel deploy --prod --no-cache` |

---

## Environment Variables in Build

Your deployment uses these secrets (set in Vercel Dashboard):
- `DATABASE_URL` - Passed to Prisma
- `NEXTAUTH_SECRET` - Passed to NextAuth
- `NEXTAUTH_URL` - Set to domain

Build logs NEVER show secret values (redacted as `***`)

---

## GitOps Workflow (Current Setup)

```
1. Edit code locally
2. git add .
3. git commit -m "message"
4. git push origin main
   ↓
5. GitHub webhook triggers Vercel
6. Vercel auto-builds & deploys
7. Site live in 2-5 minutes
   ↓
8. No manual deploy needed!
```

**Advantages:**
- ✅ Automatic deployment on every push
- ✅ Tracking via commit history
- ✅ Easy rollback (revert commit, redeploy)
- ✅ No manual commands needed

---

## Check Build Status Right Now

### Live Dashboard
https://vercel.com/dashboard/executiveusa/goldenhearts

### CLI Command
```powershell
vercel list
```

### GitHub Actions
https://github.com/executiveusa/goldenhearts/actions

### Check if site is live
```powershell
curl -I https://goldenhearts-beta.vercel.app
```

