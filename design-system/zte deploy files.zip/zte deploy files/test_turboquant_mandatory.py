"""
Test: TurboQuant mandatory enforcement
Verify that compression is working and mandatory.
"""

import pytest
import numpy as np
import asyncio
from archonx.inference.turboquant_engine import (
    TurboQuantEngine,
    TurboQuantMandatory,
)
from archonx.inference.circuit_breaker import TurboQuantCircuitBreaker
from archonx.inference.metrics_recorder import MetricsRecorder


class TestTurboQuantEngine:
    """Test core TurboQuant compression algorithm."""
    
    def test_engine_initialization(self):
        """Engine should initialize with correct parameters."""
        engine = TurboQuantEngine(dim=768, bits=3)
        
        assert engine.dim == 768
        assert engine.bits == 3
        assert engine.n_centroids == 8  # 2^3
        assert engine.compression_ratio == 6.0
        
        print("✅ Engine initialization test passed")
    
    def test_compression_ratio(self):
        """Compression must achieve >= 6x on typical KV cache."""
        engine = TurboQuantEngine(dim=768, bits=3)
        
        # Simulate 100K token context
        n_vectors = 1000
        kv_vectors = np.random.randn(n_vectors, 768).astype(np.float32)
        
        result = engine.compress(kv_vectors)
        
        assert result.compression_ratio >= 6.0, (
            f"Ratio {result.compression_ratio} < 6.0"
        )
        print(f"✅ Compression ratio test passed: {result.compression_ratio:.1f}x")
    
    def test_accuracy_preservation(self):
        """Decompressed vectors must match original within MSE < 1e-4."""
        engine = TurboQuantEngine(dim=768, bits=3)
        
        kv_vectors = np.random.randn(500, 768).astype(np.float32)
        
        result = engine.compress(kv_vectors)
        recovered = engine.decompress(result)
        
        mse = np.mean((kv_vectors - recovered) ** 2)
        
        assert mse < 1e-4, f"MSE {mse} >= 1e-4"
        print(f"✅ Accuracy test passed: MSE {mse:.6f} < 1e-4")
    
    def test_compression_result_metadata(self):
        """CompressionResult should contain all required metadata."""
        engine = TurboQuantEngine(dim=768, bits=3)
        
        kv_vectors = np.random.randn(100, 768).astype(np.float32)
        result = engine.compress(kv_vectors)
        
        assert result.indices is not None
        assert result.norms is not None
        assert result.original_shape == (100, 768)
        assert result.original_bytes > 0
        assert result.compressed_bytes > 0
        assert result.compression_ratio > 0
        assert 0 <= result.mse < 1e-3
        assert result.latency_ms > 0
        
        print("✅ CompressionResult metadata test passed")


class TestTurboQuantCircuitBreaker:
    """Test circuit breaker enforcement."""
    
    def test_hard_check_compression_ratio(self):
        """Hard check: compression ratio must be >= 2.0x."""
        breaker = TurboQuantCircuitBreaker()
        
        # Should pass
        breaker.check_compression_ratio(6.0)
        assert breaker.checks_passed == 1
        
        # Should fail
        with pytest.raises(ValueError):
            breaker.check_compression_ratio(1.5)
        
        assert breaker.checks_failed == 1
        print("✅ Compression ratio hard check test passed")
    
    def test_hard_check_accuracy(self):
        """Hard check: MSE must be <= 1e-4."""
        breaker = TurboQuantCircuitBreaker()
        
        # Should pass
        breaker.check_accuracy(1e-5)
        assert breaker.checks_passed == 1
        
        # Should fail
        with pytest.raises(ValueError):
            breaker.check_accuracy(1e-3)
        
        assert breaker.checks_failed == 1
        print("✅ Accuracy hard check test passed")
    
    def test_soft_check_cost_reduction(self):
        """Soft check: cost reduction >= 30% (warn if not, but don't fail)."""
        breaker = TurboQuantCircuitBreaker()
        
        # Should pass (50% reduction)
        status = breaker.check_cost_reduction(cost_before=1.0, cost_after=0.5)
        assert status.value == "ok"
        
        # Should warn (20% reduction, below 30%)
        status = breaker.check_cost_reduction(cost_before=1.0, cost_after=0.8)
        assert status.value == "warning"
        
        print("✅ Cost reduction soft check test passed")
    
    def test_enforce_all_checks(self):
        """All checks together."""
        breaker = TurboQuantCircuitBreaker()
        
        # All good
        result = breaker.enforce_all_checks(
            ratio=6.0, mse=1e-5, cost_before=1.0, cost_after=0.2
        )
        assert result is True
        
        # Compression ratio too low (hard fail)
        with pytest.raises(ValueError):
            breaker.enforce_all_checks(
                ratio=1.5, mse=1e-5, cost_before=1.0, cost_after=0.5
            )
        
        print("✅ All checks enforcement test passed")


class TestTurboQuantMandatory:
    """Test mandatory enforcement."""
    
    def test_should_compress(self):
        """Context >= threshold should trigger compression."""
        enforcer = TurboQuantMandatory(min_context_tokens=8192)
        
        # Skip compression
        assert not enforcer.should_compress(1000)
        
        # Require compression
        assert enforcer.should_compress(20000)
        
        print("✅ Compression threshold test passed")
    
    @pytest.mark.asyncio
    async def test_enforce_compression_skip(self):
        """Short contexts should skip compression."""
        enforcer = TurboQuantMandatory(min_context_tokens=8192)
        
        result = await enforcer.enforce_compression(
            context_tokens=1000,
            context_preview="short context"
        )
        
        assert result["status"] == "SKIPPED"
        assert result["compressed"] is False
        
        print("✅ Compression skip test passed")
    
    @pytest.mark.asyncio
    async def test_enforce_compression_success(self):
        """Long contexts should compress successfully."""
        enforcer = TurboQuantMandatory(min_context_tokens=8192)
        
        result = await enforcer.enforce_compression(
            context_tokens=50000,
            context_preview="long context with 50K tokens..."
        )
        
        assert result["status"] == "OK"
        assert result["compressed"] is True
        assert result["ratio"] >= 6.0
        assert result["mse"] < 1e-4
        assert result["savings_pct"] > 80
        
        print(
            f"✅ Compression success test passed: "
            f"{result['ratio']:.1f}x, "
            f"{result['savings_pct']:.0f}% savings"
        )
    
    def test_stats_tracking(self):
        """Stats should be tracked accurately."""
        enforcer = TurboQuantMandatory()
        
        # Get initial stats
        stats = enforcer.get_stats()
        assert stats["total_calls"] == 0
        
        print("✅ Stats tracking test passed")


class TestMetricsRecorder:
    """Test metrics recording."""
    
    def test_initialization(self, tmp_path):
        """Recorder should initialize with valid path."""
        db_path = str(tmp_path / "metrics.json")
        recorder = MetricsRecorder(db_path=db_path)
        
        assert recorder.db_path.exists()
        
        print("✅ Metrics recorder initialization test passed")
    
    def test_record_inference(self, tmp_path):
        """Should record inference metrics."""
        db_path = str(tmp_path / "metrics.json")
        recorder = MetricsRecorder(db_path=db_path)
        
        recorder.record_inference(
            agent_name="synthia",
            context_tokens=50000,
            compression_ratio=6.0,
            cost_before=0.50,
            cost_after=0.08,
            savings=0.42,
            savings_pct=84,
            latency_ms=150,
            mse=1e-5,
            status="OK"
        )
        
        stats = recorder.get_stats()
        assert stats["total_inferences"] == 1
        assert stats["successful"] == 1
        
        print("✅ Metrics recording test passed")
    
    def test_get_stats(self, tmp_path):
        """Stats should aggregate correctly."""
        db_path = str(tmp_path / "metrics.json")
        recorder = MetricsRecorder(db_path=db_path)
        
        # Record multiple
        for i in range(3):
            recorder.record_inference(
                agent_name=f"agent_{i}",
                context_tokens=50000 + (i * 1000),
                compression_ratio=6.0,
                cost_before=0.50,
                cost_after=0.08,
                savings=0.42,
                savings_pct=84,
                latency_ms=150 + (i * 10),
                mse=1e-5,
                status="OK"
            )
        
        stats = recorder.get_stats()
        assert stats["total_inferences"] == 3
        assert stats["successful"] == 3
        assert stats["avg_compression_ratio"] == 6.0
        
        print(f"✅ Stats aggregation test passed: {stats}")


class TestIntegration:
    """Integration tests."""
    
    @pytest.mark.asyncio
    async def test_full_pipeline(self):
        """Full compression pipeline test."""
        # Create enforcer
        enforcer = TurboQuantMandatory(min_context_tokens=8192)
        
        # Request with long context
        result = await enforcer.enforce_compression(context_tokens=100000)
        
        assert result["status"] == "OK"
        assert result["compressed"] is True
        assert result["ratio"] >= 6.0
        
        # Check enforcer stats
        stats = enforcer.get_stats()
        assert stats["compressed"] > 0
        
        print(
            f"✅ Full pipeline integration test passed: "
            f"Compressed {stats['compressed']} inference(s)"
        )


# Run tests if executed directly
if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
